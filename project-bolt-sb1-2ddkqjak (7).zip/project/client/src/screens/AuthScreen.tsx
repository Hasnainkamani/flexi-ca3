import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { Wallet, Mail, Lock, ArrowRight, Loader2, ChevronLeft } from 'lucide-react';

export function AuthScreen() {
  const { signUp, signIn } = useAuth();
  const [mode, setMode] = useState<'signin' | 'signup'>('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const fn = mode === 'signup' ? signUp : signIn;
    const { error } = await fn(email, password);
    if (error) setError(error);
    setLoading(false);
  }

  return (
    <div className="min-h-screen flex">
      {/* Left — brand panel (brighter) */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-emerald-500 via-teal-500 to-cyan-500 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10"
          style={{
            backgroundImage:
              'radial-gradient(circle at 30% 20%, white 0%, transparent 40%), radial-gradient(circle at 70% 80%, white 0%, transparent 40%)',
          }}
        />
        <div className="relative z-10 flex flex-col justify-between p-12 text-white">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <Wallet size={24} className="text-white" />
            </div>
            <span className="text-xl font-bold">PaisaWise</span>
          </div>
          <div>
            <h1 className="text-4xl font-bold leading-tight mb-4">
              Apna paisa,<br />samajhdari se.
            </h1>
            <p className="text-white/80 text-lg max-w-md">
              Track your income, monitor expenses, set budgets, and see exactly where
              every rupee goes — all in one beautiful dashboard.
            </p>
            <div className="mt-8 flex gap-8">
              <div>
                <p className="text-3xl font-bold">11+</p>
                <p className="text-sm text-white/70">Categories</p>
              </div>
              <div>
                <p className="text-3xl font-bold">6</p>
                <p className="text-sm text-white/70">Powerful pages</p>
              </div>
              <div>
                <p className="text-3xl font-bold">100%</p>
                <p className="text-sm text-white/70">Private</p>
              </div>
            </div>
          </div>
          <p className="text-sm text-white/60">© 2026 PaisaWise. Your data stays yours.</p>
        </div>
      </div>

      {/* Right — form */}
      <div className="flex-1 flex items-center justify-center p-6 bg-slate-50 dark:bg-slate-950">
        <div className="w-full max-w-sm animate-fade-in">
          <div className="lg:hidden flex items-center gap-3 mb-8 justify-center">
            <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center">
              <Wallet size={22} className="text-white" />
            </div>
            <span className="text-xl font-bold text-slate-900 dark:text-white">PaisaWise</span>
          </div>

          <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-1">
            {mode === 'signup' ? 'Create your account' : 'Welcome back'}
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">
            {mode === 'signup'
              ? 'Start tracking your finances in seconds.'
              : 'Sign in to see your dashboard.'}
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Email</label>
              <div className="relative">
                <Mail size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="input pl-11"
                />
              </div>
            </div>
            <div>
              <label className="label">Password</label>
              <div className="relative">
                <Lock size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="input pl-11"
                />
              </div>
            </div>

            {error && (
              <div className="px-4 py-3 rounded-xl bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 text-sm">
                {error}
              </div>
            )}

            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? (
                <Loader2 size={18} className="animate-spin" />
              ) : (
                <>
                  {mode === 'signup' ? 'Create account' : 'Sign in'}
                  <ArrowRight size={18} />
                </>
              )}
            </button>
          </form>

          <p className="text-center text-sm text-slate-500 dark:text-slate-400 mt-6">
            {mode === 'signup' ? 'Already have an account?' : "Don't have an account?"}{' '}
            <button
              onClick={() => {
                setMode(mode === 'signup' ? 'signin' : 'signup');
                setError(null);
              }}
              className="font-semibold text-emerald-600 hover:text-emerald-700"
            >
              {mode === 'signup' ? 'Sign in' : 'Sign up'}
            </button>
          </p>

          <button
            onClick={() => window.location.reload()}
            className="w-full flex items-center justify-center gap-1 text-sm text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 mt-4 transition-colors"
          >
            <ChevronLeft size={16} /> Back to home
          </button>
        </div>
      </div>
    </div>
  );
}
