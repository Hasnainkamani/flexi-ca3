import {
  Wallet, TrendingUp, Target, PieChart, Shield, Smartphone,
  ArrowRight, Check, PiggyBank, Bell, Zap,
} from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
}

export function LandingPage({ onGetStarted }: LandingPageProps) {
  const features = [
    { icon: PieChart, title: 'Visual Dashboard', desc: 'Beautiful charts that show where your money goes, month by month.' },
    { icon: Target, title: 'Smart Budgets', desc: 'Set per-category limits and get warnings before you overspend.' },
    { icon: PiggyBank, title: 'Savings Goals', desc: 'Track progress toward your dreams — vacations, emergency funds, and more.' },
    { icon: TrendingUp, title: 'Deep Analytics', desc: 'Year-over-year trends, savings rate, and your best spending months.' },
    { icon: Shield, title: 'Bank-level Security', desc: 'Your data is protected with row-level security. Only you can see it.' },
    { icon: Smartphone, title: 'Works Everywhere', desc: 'Responsive design that looks great on your phone, tablet, and desktop.' },
  ];

  const stats = [
    { value: '11+', label: 'Default categories' },
    { value: '6', label: 'Powerful pages' },
    { value: '100%', label: 'Your data, private' },
    { value: '₹0', label: 'Free to use' },
  ];

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950">
      {/* Nav */}
      <nav className="sticky top-0 z-40 bg-white/80 dark:bg-slate-950/80 backdrop-blur-lg border-b border-slate-100 dark:border-slate-800">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
              <Wallet size={20} className="text-white" />
            </div>
            <span className="text-lg font-bold text-slate-900 dark:text-white">PaisaWise</span>
          </div>
          <button onClick={onGetStarted} className="btn-primary">
            Get Started <ArrowRight size={18} />
          </button>
        </div>
      </nav>

      {/* Hero — bright gradient */}
      <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50 via-white to-white dark:from-slate-900 dark:via-slate-950 dark:to-slate-950">
        <div className="absolute inset-0 opacity-30 dark:opacity-10"
          style={{
            backgroundImage:
              'radial-gradient(circle at 25% 25%, #10b981 0%, transparent 50%), radial-gradient(circle at 75% 75%, #06b6d4 0%, transparent 50%)',
          }}
        />
        <div className="relative max-w-6xl mx-auto px-6 pt-24 pb-28 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-100 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 text-sm font-medium mb-6 animate-slide-up">
            <Zap size={14} /> Smart money management
          </div>
          <h1 className="text-5xl sm:text-6xl font-bold text-slate-900 dark:text-white leading-[1.1] mb-6 animate-slide-up" style={{ animationDelay: '0.05s' }}>
            Apna paisa,<br /><span className="bg-gradient-to-r from-emerald-600 to-teal-500 bg-clip-text text-transparent">samajhdari se.</span>
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-xl mx-auto mb-10 animate-slide-up" style={{ animationDelay: '0.1s' }}>
            Track income, monitor expenses, set budgets, chase savings goals, and see
            exactly where every rupee goes — all in one beautiful, secure dashboard.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center animate-slide-up" style={{ animationDelay: '0.15s' }}>
            <button onClick={onGetStarted} className="btn-primary px-7 py-3 text-base">
              Create free account <ArrowRight size={20} />
            </button>
            <button onClick={onGetStarted} className="btn-secondary px-7 py-3 text-base">
              See it in action
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 mt-20 max-w-3xl mx-auto animate-slide-up" style={{ animationDelay: '0.2s' }}>
            {stats.map((s) => (
              <div key={s.label}>
                <p className="text-3xl font-bold text-slate-900 dark:text-white">{s.value}</p>
                <p className="text-sm text-slate-500 dark:text-slate-400">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-6 py-20">
        <div className="text-center mb-14">
          <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-3">
            Everything you need to manage money
          </h2>
          <p className="text-slate-600 dark:text-slate-400">
            Powerful features wrapped in a clean, intuitive interface.
          </p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f, i) => {
            const Icon = f.icon;
            return (
              <div
                key={i}
                className="card p-6 hover:shadow-md transition-shadow animate-slide-up"
                style={{ animationDelay: `${i * 0.05}s` }}
              >
                <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center mb-4">
                  <Icon size={24} className="text-emerald-600 dark:text-emerald-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">{f.title}</h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">{f.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Showcase */}
      <section className="bg-slate-50 dark:bg-slate-900 py-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">
                Insights that actually matter
              </h2>
              <p className="text-slate-600 dark:text-slate-400 mb-6">
                Donut charts show your spending breakdown. Bar charts compare income
                vs. expense over 6 months. Trend cards highlight month-over-month
                changes. Analytics reveals your savings rate and best months.
              </p>
              <ul className="space-y-3">
                {[
                  'Visual income vs. expense comparison',
                  'Category-by-category spending breakdown',
                  'Year-long analytics with savings rate',
                  'Budget tracking with smart alerts',
                ].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-slate-700 dark:text-slate-300">
                    <div className="w-5 h-5 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center shrink-0">
                      <Check size={13} className="text-emerald-600 dark:text-emerald-400" />
                    </div>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="relative">
              <div className="card p-6 animate-float">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-slate-500">Monthly Overview</p>
                    <p className="text-2xl font-bold text-slate-900 dark:text-white">₹24,050</p>
                  </div>
                  <div className="flex gap-2">
                    <div className="px-3 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 text-xs font-semibold">
                      +12% income
                    </div>
                  </div>
                </div>
                <div className="flex items-end justify-between gap-2 h-32 mb-4">
                  {[40, 65, 45, 80, 55, 70].map((h, i) => (
                    <div key={i} className="flex-1 flex flex-col gap-1 items-center">
                      <div className="w-full rounded-t-md bg-emerald-400" style={{ height: `${h}%` }} />
                      <div className="w-full rounded-t-md bg-rose-400" style={{ height: `${h * 0.6}%` }} />
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-sm bg-emerald-400" /> Income
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-sm bg-rose-400" /> Expense
                  </div>
                </div>
              </div>
              <div className="card p-4 absolute -bottom-6 -right-6 w-48 hidden sm:block animate-float" style={{ animationDelay: '1s' }}>
                <div className="flex items-center gap-2 mb-2">
                  <Bell size={16} className="text-amber-500" />
                  <span className="text-xs font-semibold text-slate-900 dark:text-white">Budget Alert</span>
                </div>
                <p className="text-xs text-slate-500">Food is at 85% of your monthly limit</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-4xl mx-auto px-6 py-20 text-center">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">
          Ready to take control?
        </h2>
        <p className="text-slate-600 dark:text-slate-400 mb-8">
          Join PaisaWise today. It's free, secure, and takes 30 seconds to set up.
        </p>
        <button onClick={onGetStarted} className="btn-primary px-8 py-3 text-base">
          Get started for free <ArrowRight size={20} />
        </button>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-100 dark:border-slate-800 py-8">
        <div className="max-w-6xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
              <Wallet size={16} className="text-white" />
            </div>
            <span className="font-bold text-slate-900 dark:text-white">PaisaWise</span>
          </div>
          <p className="text-sm text-slate-500">© 2026 PaisaWise. Your data stays yours.</p>
        </div>
      </footer>
    </div>
  );
}
