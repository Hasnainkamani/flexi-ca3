import { useMemo, useState } from 'react';
import type { Category, Transaction } from '@/lib/types';
import { formatCurrency } from '@/lib/format';
import { computeMonthlyStats } from '@/hooks/useData';
import { DonutChart } from '@/components/DonutChart';
import { BarChart } from '@/components/BarChart';
import { TrendingUp, TrendingDown, ArrowUp, ArrowDown, Calendar, Award, PiggyBank } from 'lucide-react';

interface AnalyticsProps {
  categories: Category[];
  transactions: Transaction[];
  loading: boolean;
}

export function Analytics({ categories, transactions, loading }: AnalyticsProps) {
  const [cursor, setCursor] = useState(() => new Date());

  const year = cursor.getFullYear();

  // 12-month income vs expense
  const monthlyData = useMemo(() => {
    const months: { label: string; income: number; expense: number; balance: number }[] = [];
    for (let i = 0; i < 12; i++) {
      const m = new Date(year, i, 1);
      const s = computeMonthlyStats(transactions, year, i);
      months.push({
        label: m.toLocaleDateString('en-US', { month: 'short' }),
        income: s.income,
        expense: s.expense,
        balance: s.balance,
      });
    }
    return months;
  }, [transactions, year]);

  const yearStats = useMemo(() => {
    let income = 0, expense = 0;
    for (const m of monthlyData) {
      income += m.income;
      expense += m.expense;
    }
    return { income, expense, balance: income - expense, savingsRate: income > 0 ? ((income - expense) / income) * 100 : 0 };
  }, [monthlyData]);

  // Top expense categories (year)
  const topCategories = useMemo(() => {
    const map = new Map<string, number>();
    for (const t of transactions) {
      if (t.type !== 'expense') continue;
      const d = new Date(t.date + 'T00:00:00');
      if (d.getFullYear() !== year) continue;
      const cat = t.category ?? categories.find((c) => c.id === t.category_id);
      const key = cat?.id ?? 'uncat';
      map.set(key, (map.get(key) ?? 0) + Number(t.amount));
    }
    const total = Array.from(map.values()).reduce((s, v) => s + v, 0);
    return Array.from(map.entries())
      .map(([catId, value]) => {
        const cat = categories.find((c) => c.id === catId);
        return {
          label: cat?.name ?? 'Uncategorized',
          value,
          color: cat?.color ?? '#94a3b8',
          pct: total > 0 ? (value / total) * 100 : 0,
        };
      })
      .sort((a, b) => b.value - a.value);
  }, [transactions, categories, year]);

  // Month-over-month trend
  const monthTrend = useMemo(() => {
    const currentMonth = monthlyData[cursor.getMonth()];
    const prevMonth = cursor.getMonth() === 0 ? monthlyData[11] : monthlyData[cursor.getMonth() - 1];
    const incomeChange = prevMonth.income > 0 ? ((currentMonth.income - prevMonth.income) / prevMonth.income) * 100 : 0;
    const expenseChange = prevMonth.expense > 0 ? ((currentMonth.expense - prevMonth.expense) / prevMonth.expense) * 100 : 0;
    return { currentMonth, prevMonth, incomeChange, expenseChange };
  }, [monthlyData, cursor]);

  // Average per transaction
  const avgTransaction = useMemo(() => {
    const yearTx = transactions.filter((t) => new Date(t.date + 'T00:00:00').getFullYear() === year);
    if (yearTx.length === 0) return 0;
    const total = yearTx.reduce((sum, t) => sum + Number(t.amount), 0);
    return total / yearTx.length;
  }, [transactions, year]);

  // Biggest transaction
  const biggestExpense = useMemo(() => {
    const yearExp = transactions.filter((t) => {
      if (t.type !== 'expense') return false;
      return new Date(t.date + 'T00:00:00').getFullYear() === year;
    });
    if (yearExp.length === 0) return null;
    return yearExp.reduce((max, t) => (Number(t.amount) > Number(max.amount) ? t : max));
  }, [transactions, year]);

  // Best saving month
  const bestMonth = useMemo(() => {
    let best = monthlyData[0];
    let bestIdx = 0;
    monthlyData.forEach((m, i) => {
      if (m.balance > best.balance) { best = m; bestIdx = i; }
    });
    return { ...best, idx: bestIdx };
  }, [monthlyData]);

  const prevYear = () => setCursor(new Date(year - 1, cursor.getMonth(), 1));
  const nextYear = () => setCursor(new Date(year + 1, cursor.getMonth(), 1));

  const donutData = topCategories.map((c) => ({ label: c.label, value: c.value, color: c.color }));

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Analytics</h1>
          <p className="text-slate-500 text-sm mt-1">Deep insights into your spending patterns.</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={prevYear} className="btn-secondary !p-2.5">
            <ArrowUp size={16} className="rotate-[-90deg]" />
          </button>
          <span className="px-4 py-2.5 text-sm font-semibold text-slate-700 min-w-[6rem] text-center">{year}</span>
          <button onClick={nextYear} className="btn-secondary !p-2.5">
            <ArrowDown size={16} className="rotate-[-90deg]" />
          </button>
        </div>
      </div>

      {loading ? (
        <div className="card p-12 text-center text-slate-400 text-sm">Loading…</div>
      ) : transactions.length === 0 ? (
        <div className="card p-12 text-center">
          <p className="text-slate-400 text-sm">Add transactions to see analytics.</p>
        </div>
      ) : (
        <>
          {/* Year summary cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="card p-5 bg-emerald-50 border-0">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-slate-600">Year Income</span>
                <div className="w-9 h-9 rounded-xl bg-emerald-100 flex items-center justify-center">
                  <TrendingUp size={18} className="text-emerald-600" />
                </div>
              </div>
              <p className="text-2xl font-bold text-slate-900">{formatCurrency(yearStats.income)}</p>
            </div>
            <div className="card p-5 bg-rose-50 border-0">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-slate-600">Year Expenses</span>
                <div className="w-9 h-9 rounded-xl bg-rose-100 flex items-center justify-center">
                  <TrendingDown size={18} className="text-rose-600" />
                </div>
              </div>
              <p className="text-2xl font-bold text-slate-900">{formatCurrency(yearStats.expense)}</p>
            </div>
            <div className="card p-5 bg-blue-50 border-0">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-slate-600">Net Balance</span>
                <div className="w-9 h-9 rounded-xl bg-blue-100 flex items-center justify-center">
                  <PiggyBank size={18} className="text-blue-600" />
                </div>
              </div>
              <p className="text-2xl font-bold text-slate-900">{formatCurrency(yearStats.balance)}</p>
            </div>
            <div className="card p-5 bg-amber-50 border-0">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-slate-600">Savings Rate</span>
                <div className="w-9 h-9 rounded-xl bg-amber-100 flex items-center justify-center">
                  <Award size={18} className="text-amber-600" />
                </div>
              </div>
              <p className="text-2xl font-bold text-slate-900">{yearStats.savingsRate.toFixed(1)}%</p>
            </div>
          </div>

          {/* Monthly trend */}
          <div className="card p-6">
            <h3 className="font-semibold text-slate-900 mb-1">Monthly Income vs Expense — {year}</h3>
            <p className="text-xs text-slate-500 mb-5">Full year breakdown</p>
            <BarChart data={monthlyData.map((m) => ({ label: m.label, income: m.income, expense: m.expense }))} />
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Category breakdown */}
            <div className="card p-6">
              <h3 className="font-semibold text-slate-900 mb-1">Expense Breakdown</h3>
              <p className="text-xs text-slate-500 mb-5">By category for {year}</p>
              {donutData.length === 0 ? (
                <div className="h-48 flex items-center justify-center text-slate-400 text-sm">No expenses in {year}</div>
              ) : (
                <div className="flex flex-col items-center">
                  <DonutChart
                    data={donutData}
                    centerLabel="Year"
                    centerValue={formatCurrency(yearStats.expense).replace('.00', '')}
                  />
                </div>
              )}
            </div>

            {/* Top categories list */}
            <div className="card p-6 lg:col-span-2">
              <h3 className="font-semibold text-slate-900 mb-4">Top Categories — {year}</h3>
              {topCategories.length === 0 ? (
                <div className="py-8 text-center text-slate-400 text-sm">No data</div>
              ) : (
                <div className="space-y-3">
                  {topCategories.slice(0, 8).map((c, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-lg flex items-center justify-center text-white text-xs font-bold shrink-0" style={{ backgroundColor: c.color }}>
                        {i + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium text-slate-900 truncate">{c.label}</span>
                          <span className="text-sm font-semibold text-slate-900 ml-2">{formatCurrency(c.value)}</span>
                        </div>
                        <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{ width: `${c.pct}%`, backgroundColor: c.color }}
                          />
                        </div>
                        <span className="text-xs text-slate-500">{c.pct.toFixed(1)}% of total</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Insights cards */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* MoM income */}
            <div className="card p-5">
              <div className="flex items-center gap-2 mb-2">
                <Calendar size={16} className="text-slate-400" />
                <span className="text-sm text-slate-600">Income vs last month</span>
              </div>
              <p className="text-xl font-bold text-slate-900">{formatCurrency(monthTrend.currentMonth.income)}</p>
              {monthTrend.prevMonth.income > 0 && (
                <p className={`text-sm font-medium mt-1 flex items-center gap-1 ${
                  monthTrend.incomeChange >= 0 ? 'text-emerald-600' : 'text-rose-600'
                }`}>
                  {monthTrend.incomeChange >= 0 ? <ArrowUp size={14} /> : <ArrowDown size={14} />}
                  {Math.abs(monthTrend.incomeChange).toFixed(1)}% vs {monthTrend.prevMonth.label}
                </p>
              )}
            </div>

            {/* MoM expense */}
            <div className="card p-5">
              <div className="flex items-center gap-2 mb-2">
                <Calendar size={16} className="text-slate-400" />
                <span className="text-sm text-slate-600">Expense vs last month</span>
              </div>
              <p className="text-xl font-bold text-slate-900">{formatCurrency(monthTrend.currentMonth.expense)}</p>
              {monthTrend.prevMonth.expense > 0 && (
                <p className={`text-sm font-medium mt-1 flex items-center gap-1 ${
                  monthTrend.expenseChange <= 0 ? 'text-emerald-600' : 'text-rose-600'
                }`}>
                  {monthTrend.expenseChange <= 0 ? <ArrowDown size={14} /> : <ArrowUp size={14} />}
                  {Math.abs(monthTrend.expenseChange).toFixed(1)}% vs {monthTrend.prevMonth.label}
                </p>
              )}
            </div>

            {/* Avg transaction */}
            <div className="card p-5">
              <div className="flex items-center gap-2 mb-2">
                <PiggyBank size={16} className="text-slate-400" />
                <span className="text-sm text-slate-600">Avg Transaction</span>
              </div>
              <p className="text-xl font-bold text-slate-900">{formatCurrency(avgTransaction)}</p>
              <p className="text-xs text-slate-500 mt-1">
                Biggest: {biggestExpense ? formatCurrency(Number(biggestExpense.amount)) : '—'}
              </p>
            </div>
          </div>

          {/* Best month highlight */}
          {bestMonth.balance > 0 && (
            <div className="card p-6 bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-100">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500 flex items-center justify-center">
                  <Award size={24} className="text-white" />
                </div>
                <div>
                  <p className="text-sm text-emerald-700 font-medium">Best savings month in {year}</p>
                  <p className="text-xl font-bold text-slate-900">
                    {bestMonth.label} — {formatCurrency(bestMonth.balance)} saved
                  </p>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
