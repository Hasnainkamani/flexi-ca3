import { api } from './api';
import type { Category } from './types';

interface DefaultCategory {
  name: string;
  type: 'income' | 'expense';
  color: string;
  icon: string;
}

const DEFAULT_CATEGORIES: DefaultCategory[] = [
  { name: 'Salary', type: 'income', color: '#10b981', icon: 'Wallet' },
  { name: 'Freelance', type: 'income', color: '#14b8a6', icon: 'Laptop' },
  { name: 'Other Income', type: 'income', color: '#84cc16', icon: 'Plus' },
  { name: 'Food & Dining', type: 'expense', color: '#f97316', icon: 'UtensilsCrossed' },
  { name: 'Transport', type: 'expense', color: '#3b82f6', icon: 'Car' },
  { name: 'Shopping', type: 'expense', color: '#ec4899', icon: 'ShoppingBag' },
  { name: 'Entertainment', type: 'expense', color: '#0ea5e9', icon: 'Film' },
  { name: 'Bills & Utilities', type: 'expense', color: '#ef4444', icon: 'Receipt' },
  { name: 'Health', type: 'expense', color: '#06b6d4', icon: 'HeartPulse' },
  { name: 'Housing', type: 'expense', color: '#d97706', icon: 'Home' },
  { name: 'Other', type: 'expense', color: '#64748b', icon: 'MoreHorizontal' },
];

export async function seedDefaultCategories(): Promise<void> {
  const existing = await api.categories();
  if (existing.length > 0) return;
  await Promise.all(DEFAULT_CATEGORIES.map((category) => api.create<Category>('categories', category))); 
}

export { DEFAULT_CATEGORIES };
export type { DefaultCategory };
