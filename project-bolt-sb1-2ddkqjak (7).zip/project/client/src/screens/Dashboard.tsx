import { useMemo, useState } from 'react';
import type { Category, Transaction } from '@/lib/types';
import { formatCurrency, formatCompactCurrency, formatMonth, monthKey } from '@/lib/format';
import { computeMonthlyStats } from '@/hooks/useData';
import { DonutChart } from '@/components/DonutChart';
import { LineChart } from '@/components/LineChart';
import { Sparkline } from '@/components/Sparkline';
import {
  TrendingUp, TrendingDown, Wallet, ArrowLeftRight,
  ChevronLeft, ChevronRight, ArrowUp, ArrowDown,
  Sparkles, Calendar, Award, Lightbulb,
} from 'lucide-react';

interface DashboardProps {
  categories: Category[];
  transactions: Transaction[];
  loading: boolean;
}

export function Dashboard({ categories, transactions, loading }: DashboardProps) {
  const [cursor, setCursor] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });

  const stats = useMemo(
    () => computeMonthlyStats(transactions, cursor.getFullYear(), cursor.getMonth()),
    [transactions, cursor]
  );

  const prevStats = useMemo(
    () => computeMonthlyStats(transactions, cursor.getFullYear(), cursor.getMonth() - 1),
    [transactions, cursor]
  );

  const expenseByCategory = useMemo(() => {
    const map = new Map<string, number>();
    for (const t of transactions) {
      if (t.type !== 'expense') continue;
      const d = new Date(t.date + 'T00:00:00');
      if (d.getFullYear() === cursor.getFullYear() && d.getMonth() === cursor.getMonth()) {
        const cat = t.category ?? categories.find((c) => c.id === t.category_id);
        const key = cat?.id ?? 'uncat';
        map.set(key, (map.get(key) ?? 0) + Number(t.amount));
      }
    }
    return Array.from(map.entries())
      .map(([catId, value]) => {
        const cat = categories.find((c) => c.id === catId);
        return { label: cat?.name ?? 'Uncategorized', value, color: cat?.color ?? '#94a3b8' };
      })
      .sort((a, b) => b.value - a.value);
  }, [transactions, categories, cursor]);

  const lastSixMonths = useMemo(() => {
    const months: { label: string; income: number; expense: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(cursor.getFullYear(), cursor.getMonth() - i, 1);
      const s = computeMonthlyStats(transactions, d.getFullYear(), d.getMonth());
      months.push({
        label: d.toLocaleDateString('en-IN', { month: 'short' }),
        income: s.income,
        expense: s.expense,
      });
    }
    return months;
  }, [transactions, cursor]);

  // 6-month sparklines for stat cards
  const incomeSpark = useMemo(() => lastSixMonths.map((m) => m.income), [lastSixMonths]);
  const expenseSpark = useMemo(() => lastSixMonths.map((m) => m.expense), [lastSixMonths]);
  const balanceSpark = useMemo(() => lastSixMonths.map((m) => m.income - m.expense), [lastSixMonths]);

  // Daily spending for current month
  const dailySpending = useMemo(() => {
    const daysInMonth = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
    const today = new Date();
    const isCurrentMonth = today.getFullYear() === cursor.getFullYear() && today.getMonth() === cursor.getMonth();
    const cutoff = isCurrentMonth ? today.getDate() : daysInMonth;

    const buckets = new Array(daysInMonth).fill(0);
    for (const t of transactions) {
      if (t.type !== 'expense') continue;
      const d = new Date(t.date + 'T00:00:00');
      if (d.getFullYear() === cursor.getFullYear() && d.getMonth() === cursor.getMonth()) {
        buckets[d.getDate() - 1] += Number(t.amount);
      }
    }
    return { buckets: buckets.slice(0, cutoff), daysInMonth, cutoff };
  }, [transactions, cursor]);

  const recent = useMemo(() => transactions.slice(0, 7), [transactions]);

  // Insights
  const topCategory = expenseByCategory[0] ?? null;
  const savingsRate = stats.income > 0 ? (stats.balance / stats.income) * 100 : 0;
  const monthTxCount = transactions.filter((t) => {
    const d = new Date(t.date + 'T00:00:00');
    return d.getFullYear() === cursor.getFullYear() && d.getMonth() === cursor.getMonth();
  }).length;
  const avgDailySpending = dailySpending.cutoff > 0 ? stats.expense / dailySpending.cutoff : 0;

  // Trend percentages
  const incomeTrend = prevStats.income > 0 ? ((stats.income - prevStats.income) / prevStats.income) * 100 : null;
  const expenseTrend = prevStats.expense > 0 ? ((stats.expense - prevStats.expense) / prevStats.expense) * 100 : null;

  const prevMonth = () => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1));
  const nextMonth = () => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1));

  const isCurrentMonth =
    new Date().getFullYear() === cursor.getFullYear() && new Date().getMonth() === cursor.getMonth();

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Dashboard</h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
            Welcome back — here's your financial overview.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={prevMonth} className="btn-secondary !p-2.5">
            <ChevronLeft size={18} />
          </button>
          <span className="px-4 py-2.5 text-sm font-semibold text-slate-700 dark:text-slate-200 min-w-[10rem] text-center">
            {formatMonth(monthKey(cursor))}
          </span>
          <button onClick={nextMonth} className="btn-secondary !p-2.5">
            <ChevronRight size={18} />
          </button>
        </div>
      </div>

      {/* Hero row: balance card + stat cards */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Hero balance card */}
        <div className="lg:col-span-2 relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-600 p-6 text-white shadow-lg shadow-emerald-600/20">
          <div className="absolute inset-0 opacity-20"
            style={{
              backgroundImage:
                'radial-gradient(circle at 80% 20%, white 0%, transparent 50%), radial-gradient(circle at 20% 80%, white 0%, transparent 40%)',
            }}
          />
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-white/70 text-sm font-medium">Total Balance</p>
                <p className="text-3xl sm:text-4xl font-bold mt-1">{formatCurrency(stats.balance)}</p>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <Wallet size={24} />
              </div>
            </div>
            <div className="flex items-center gap-2 mb-5">
              <div className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
                savingsRate >= 0 ? 'bg-white/20' : 'bg-red-500/30'
              }`}>
                {savingsRate >= 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                {Math.abs(savingsRate).toFixed(1)}% savings rate
              </div>
              <span className="text-white/60 text-xs">{monthTxCount} transactions</span>
            </div>
            <div className="flex justify-end -mb-2">
              <Sparkline data={balanceSpark} color="#ffffff" width={200} height={48} />
            </div>
          </div>
        </div>

        {/* Income stat card */}
        <StatCard
          label="Income"
          value={formatCurrency(stats.income)}
          icon={TrendingUp}
          iconBg="bg-emerald-100 dark:bg-emerald-900/30"
          iconColor="text-emerald-600 dark:text-emerald-400"
          cardBg="bg-white dark:bg-slate-800/50"
          sparkData={incomeSpark}
          sparkColor="#10b981"
          trend={incomeTrend}
          trendGood={(v) => v >= 0}
        />

        {/* Expense stat card */}
        <StatCard
          label="Expenses"
          value={formatCurrency(stats.expense)}
          icon={TrendingDown}
          iconBg="bg-rose-100 dark:bg-rose-900/30"
          iconColor="text-rose-600 dark:text-rose-400"
          cardBg="bg-white dark:bg-slate-800/50"
          sparkData={expenseSpark}
          sparkColor="#f43f5e"
          trend={expenseTrend}
          trendGood={(v) => v <= 0}
        />
      </div>

      {/* Secondary stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <MiniStat
          label="Avg Daily Spend"
          value={formatCurrency(avgDailySpending)}
          icon={Calendar}
          iconBg="bg-blue-100 dark:bg-blue-900/30"
          iconColor="text-blue-600 dark:text-blue-400"
        />
        <MiniStat
          label="Transactions"
          value={String(monthTxCount)}
          icon={ArrowLeftRight}
          iconBg="bg-amber-100 dark:bg-amber-900/30"
          iconColor="text-amber-600 dark:text-amber-400"
        />
        <MiniStat
          label="Savings Rate"
          value={`${savingsRate.toFixed(1)}%`}
          icon={Award}
          iconBg="bg-emerald-100 dark:bg-emerald-900/30"
          iconColor="text-emerald-600 dark:text-emerald-400"
        />
        <MiniStat
          label="Top Category"
          value={topCategory?.label ?? '—'}
          subValue={topCategory ? formatCurrency(topCategory.value) : undefined}
          icon={Sparkles}
          iconBg="bg-violet-100 dark:bg-violet-900/30"
          iconColor="text-violet-600 dark:text-violet-400"
        />
      </div>

      {/* Charts row */}
      <div className="grid lg:grid-cols-5 gap-6">
        {/* Cash flow line chart */}
        <div className="card p-6 lg:col-span-3">
          <div className="flex items-center justify-between mb-1">
            <h3 className="font-semibold text-slate-900 dark:text-white">Cash Flow</h3>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-emerald-500" />
                <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Income</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-rose-500" />
                <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Expense</span>
              </div>
            </div>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">Last 6 months</p>
          <LineChart data={lastSixMonths} />
        </div>

        {/* Donut */}
        <div className="card p-6 lg:col-span-2">
          <h3 className="font-semibold text-slate-900 dark:text-white mb-1">Spending by Category</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">{formatMonth(monthKey(cursor))}</p>
          {loading ? (
            <div className="h-48 flex items-center justify-center text-slate-400 text-sm">Loading…</div>
          ) : expenseByCategory.length === 0 ? (
            <div className="h-48 flex flex-col items-center justify-center text-slate-400 text-sm gap-2">
              <div className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                <Wallet size={24} className="text-slate-300" />
              </div>
              No expenses this month
            </div>
          ) : (
            <div className="flex flex-col items-center">
              <DonutChart
                data={expenseByCategory}
                centerLabel="Spent"
                centerValue={formatCompactCurrency(stats.expense)}
                centerSubValue={`${expenseByCategory.length} categories`}
              />
              <div className="w-full mt-5 space-y-2">
                {expenseByCategory.slice(0, 5).map((c, i) => (
                  <div key={i} className="flex items-center justify-between text-sm group">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-3 h-3 rounded-sm shrink-0" style={{ backgroundColor: c.color }} />
                      <span className="text-slate-600 dark:text-slate-300 truncate">{c.label}</span>
                    </div>
                    <span className="font-medium text-slate-900 dark:text-white ml-2">
                      {formatCurrency(c.value)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Daily spending + Recent transactions */}
      <div className="grid lg:grid-cols-5 gap-6">
        {/* Daily spending bars */}
        <div className="card p-6 lg:col-span-2">
          <h3 className="font-semibold text-slate-900 dark:text-white mb-1">Daily Spending</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-5">
            {isCurrentMonth ? 'This month so far' : formatMonth(monthKey(cursor))}
          </p>
          {dailySpending.buckets.every((b) => b === 0) ? (
            <div className="h-32 flex items-center justify-center text-slate-400 text-sm">
              No spending recorded yet
            </div>
          ) : (
            <div className="flex items-end gap-[3px] h-32">
              {dailySpending.buckets.map((amt, i) => {
                const maxDay = Math.max(...dailySpending.buckets, 1);
                const pct = (amt / maxDay) * 100;
                return (
                  <div key={i} className="flex-1 group relative flex flex-col justify-end h-full">
                    <div
                      className="w-full rounded-t-sm bg-gradient-to-t from-emerald-500 to-teal-400 transition-all duration-500 hover:from-emerald-600 hover:to-teal-500"
                      style={{ height: `${pct}%`, minHeight: amt > 0 ? '3px' : '0' }}
                    />
                    {amt > 0 && (
                      <div className="absolute -top-7 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900 text-white text-xs px-2 py-1 rounded-md whitespace-nowrap z-10 pointer-events-none">
                        Day {i + 1}: {formatCurrency(amt)}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
          <div className="flex justify-between mt-3 text-xs text-slate-400">
            <span>Day 1</span>
            <span>Day {dailySpending.cutoff}</span>
          </div>
        </div>

        {/* Recent transactions */}
        <div className="card p-6 lg:col-span-3">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-900 dark:text-white">Recent Transactions</h3>
            {recent.length > 0 && (
              <span className="text-xs text-slate-400 font-medium">Last {recent.length}</span>
            )}
          </div>
          {recent.length === 0 ? (
            <div className="py-12 text-center">
              <div className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto mb-3">
                <ArrowLeftRight size={22} className="text-slate-300" />
              </div>
              <p className="text-slate-400 text-sm">No transactions yet. Add one from the Transactions page.</p>
            </div>
          ) : (
            <div className="space-y-1 relative">
              {recent.map((t, idx) => {
                const cat = t.category ?? categories.find((c) => c.id === t.category_id);
                return (
                  <div
                    key={t.id}
                    className="flex items-center justify-between py-2.5 px-2 -mx-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors"
                    style={{ animationDelay: `${idx * 0.05}s` }}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-sm font-semibold shrink-0 shadow-sm"
                        style={{ backgroundColor: cat?.color ?? '#94a3b8' }}
                      >
                        {(cat?.name ?? '?')[0]}
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                          {t.description ?? cat?.name ?? 'Transaction'}
                        </p>
                        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-700/50 font-medium">
                            {cat?.name ?? 'Uncategorized'}
                          </span>
                          <span>{new Date(t.date + 'T00:00:00').toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <p className={`text-sm font-bold ${t.type === 'income' ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-900 dark:text-white'}`}>
                        {t.type === 'income' ? '+' : '-'}{formatCurrency(Number(t.amount))}
                      </p>
                      <p className="text-xs text-slate-400 capitalize">{t.type}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Insights row */}
      <div className="grid sm:grid-cols-3 gap-4">
        {/* Savings rate insight */}
        <div className={`card p-5 ${savingsRate >= 20 ? 'bg-emerald-50 dark:bg-emerald-900/10' : savingsRate >= 0 ? 'bg-amber-50 dark:bg-amber-900/10' : 'bg-rose-50 dark:bg-rose-900/10'} border-0`}>
          <div className="flex items-center gap-2 mb-2">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
              savingsRate >= 20 ? 'bg-emerald-100 dark:bg-emerald-900/30' : savingsRate >= 0 ? 'bg-amber-100 dark:bg-amber-900/30' : 'bg-rose-100 dark:bg-rose-900/30'
            }`}>
              <Award size={16} className={
                savingsRate >= 20 ? 'text-emerald-600' : savingsRate >= 0 ? 'text-amber-600' : 'text-rose-600'
              } />
            </div>
            <span className="text-sm font-medium text-slate-600 dark:text-slate-300">Savings Health</span>
          </div>
          <p className="text-lg font-bold text-slate-900 dark:text-white">
            {savingsRate >= 20 ? 'Excellent' : savingsRate >= 10 ? 'Good' : savingsRate >= 0 ? 'Fair' : 'Overspending'}
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {savingsRate >= 20
              ? `You're saving ${savingsRate.toFixed(0)}% of income — above the 20% benchmark.`
              : savingsRate >= 0
                ? `Saving ${savingsRate.toFixed(0)}% — aim for 20% to build wealth faster.`
                : 'You spent more than you earned this month.'}
          </p>
        </div>

        {/* Top category insight */}
        <div className="card p-5 bg-blue-50 dark:bg-blue-900/10 border-0">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
              <Lightbulb size={16} className="text-blue-600 dark:text-blue-400" />
            </div>
            <span className="text-sm font-medium text-slate-600 dark:text-slate-300">Top Expense</span>
          </div>
          {topCategory ? (
            <>
              <p className="text-lg font-bold text-slate-900 dark:text-white">{topCategory.label}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                {formatCurrency(topCategory.value)} — {((topCategory.value / Math.max(stats.expense, 1)) * 100).toFixed(0)}% of total spending
              </p>
              <div className="h-1.5 rounded-full bg-blue-100 dark:bg-blue-900/30 overflow-hidden mt-3">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.min((topCategory.value / Math.max(stats.expense, 1)) * 100, 100)}%`, backgroundColor: topCategory.color }}
                />
              </div>
            </>
          ) : (
            <p className="text-sm text-slate-500 dark:text-slate-400">No expenses recorded yet.</p>
          )}
        </div>

        {/* Month comparison */}
        <div className="card p-5 bg-violet-50 dark:bg-violet-900/10 border-0">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-lg bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center">
              <TrendingUp size={16} className="text-violet-600 dark:text-violet-400" />
            </div>
            <span className="text-sm font-medium text-slate-600 dark:text-slate-300">vs Last Month</span>
          </div>
          <div className="space-y-2 mt-2">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 dark:text-slate-400">Income</span>
              <span className={`text-sm font-bold flex items-center gap-1 ${
                (incomeTrend ?? 0) >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
              }`}>
                {incomeTrend === null ? '—' : (
                  <>
                    {(incomeTrend ?? 0) >= 0 ? <ArrowUp size={12} /> : <ArrowDown size={12} />}
                    {Math.abs(incomeTrend ?? 0).toFixed(1)}%
                  </>
                )}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 dark:text-slate-400">Expense</span>
              <span className={`text-sm font-bold flex items-center gap-1 ${
                (expenseTrend ?? 0) <= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
              }`}>
                {expenseTrend === null ? '—' : (
                  <>
                    {(expenseTrend ?? 0) <= 0 ? <ArrowDown size={12} /> : <ArrowUp size={12} />}
                    {Math.abs(expenseTrend ?? 0).toFixed(1)}%
                  </>
                )}
              </span>
            </div>
            <div className="flex items-center justify-between pt-1 border-t border-violet-100 dark:border-violet-900/30">
              <span className="text-xs font-medium text-slate-600 dark:text-slate-300">Balance</span>
              <span className="text-sm font-bold text-slate-900 dark:text-white">
                {formatCurrency(stats.balance - prevStats.balance)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// --- Stat card with sparkline + trend ---
interface StatCardProps {
  label: string;
  value: string;
  icon: typeof Wallet;
  iconBg: string;
  iconColor: string;
  cardBg: string;
  sparkData: number[];
  sparkColor: string;
  trend: number | null;
  trendGood: (v: number) => boolean;
}

function StatCard({ label, value, icon: Icon, iconBg, iconColor, cardBg, sparkData, sparkColor, trend, trendGood }: StatCardProps) {
  return (
    <div className={`card p-5 ${cardBg} border-slate-200/80 dark:border-slate-700/50 flex flex-col justify-between`}>
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm font-medium text-slate-600 dark:text-slate-300">{label}</span>
        <div className={`w-9 h-9 rounded-xl ${iconBg} flex items-center justify-center`}>
          <Icon size={18} className={iconColor} />
        </div>
      </div>
      <div className="flex items-end justify-between">
        <div>
          <p className="text-2xl font-bold text-slate-900 dark:text-white">{value}</p>
          {trend !== null && (
            <span className={`text-xs font-semibold mt-1 flex items-center gap-0.5 ${
              trendGood(trend) ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
            }`}>
              {trend >= 0 ? <ArrowUp size={11} /> : <ArrowDown size={11} />}
              {Math.abs(trend).toFixed(1)}% vs last month
            </span>
          )}
        </div>
        <Sparkline data={sparkData} color={sparkColor} width={90} height={36} />
      </div>
    </div>
  );
}

// --- Mini stat ---
interface MiniStatProps {
  label: string;
  value: string;
  subValue?: string;
  icon: typeof Wallet;
  iconBg: string;
  iconColor: string;
}

function MiniStat({ label, value, subValue, icon: Icon, iconBg, iconColor }: MiniStatProps) {
  return (
    <div className="card p-4">
      <div className="flex items-center gap-2.5 mb-2">
        <div className={`w-8 h-8 rounded-lg ${iconBg} flex items-center justify-center shrink-0`}>
          <Icon size={16} className={iconColor} />
        </div>
        <span className="text-xs font-medium text-slate-500 dark:text-slate-400 truncate">{label}</span>
      </div>
      <p className="text-lg font-bold text-slate-900 dark:text-white truncate">{value}</p>
      {subValue && <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">{subValue}</p>}
    </div>
  );
}
