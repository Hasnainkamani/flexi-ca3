import { useCallback, useEffect, useState } from 'react';
import { api } from '@/lib/api';
import type { Category, Transaction, Budget, SavingsGoal } from '@/lib/types';
import { seedDefaultCategories } from '@/lib/seed';

export interface MonthlyStats {
  income: number;
  expense: number;
  balance: number;
}

export function useData(userId: string | undefined) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [goals, setGoals] = useState<SavingsGoal[]>([]);
  const [loading, setLoading] = useState(true);

  const loadCategories = useCallback(async () => {
    if (!userId) return;
    setCategories(await api.categories());
  }, [userId]);

  const loadTransactions = useCallback(async () => {
    if (!userId) return;
    setTransactions(await api.transactions());
  }, [userId]);

  const loadBudgets = useCallback(async () => {
    if (!userId) return;
    setBudgets(await api.budgets());
  }, [userId]);

  const loadGoals = useCallback(async () => {
    if (!userId) return;
    setGoals(await api.goals());
  }, [userId]);

  const reload = useCallback(async () => {
    await Promise.all([loadCategories(), loadTransactions(), loadBudgets(), loadGoals()]);
  }, [loadCategories, loadTransactions, loadBudgets, loadGoals]);

  useEffect(() => {
    if (!userId) return;
    (async () => {
      setLoading(true);
      await seedDefaultCategories();
      await reload();
      setLoading(false);
    })();
  }, [userId, reload]);

  return { categories, transactions, budgets, goals, loading, reload, loadTransactions, loadBudgets, loadGoals, setTransactions };
}

export function computeMonthlyStats(transactions: Transaction[], year: number, month: number): MonthlyStats {
  let income = 0;
  let expense = 0;
  for (const t of transactions) {
    const d = new Date(t.date + 'T00:00:00');
    if (d.getFullYear() === year && d.getMonth() === month) {
      if (t.type === 'income') income += Number(t.amount);
      else expense += Number(t.amount);
    }
  }
  return { income, expense, balance: income - expense };
}
