import { useState } from 'react';

interface DonutSlice {
  label: string;
  value: number;
  color: string;
}

interface DonutChartProps {
  data: DonutSlice[];
  size?: number;
  thickness?: number;
  centerLabel?: string;
  centerValue?: string;
  centerSubValue?: string;
}

export function DonutChart({
  data,
  size = 200,
  thickness = 30,
  centerLabel,
  centerValue,
  centerSubValue,
}: DonutChartProps) {
  const [hovered, setHovered] = useState<number | null>(null);
  const total = data.reduce((sum, d) => sum + d.value, 0);
  const radius = (size - thickness) / 2;
  const circumference = 2 * Math.PI * radius;
  const cx = size / 2;
  const cy = size / 2;

  let offset = 0;
  const slices = total > 0
    ? data.filter((d) => d.value > 0).map((d) => {
        const fraction = d.value / total;
        const dash = fraction * circumference;
        const slice = {
          ...d,
          dashLength: dash,
          dashGap: circumference - dash,
          dashOffset: -offset,
          pct: fraction * 100,
        };
        offset += dash;
        return slice;
      })
    : [];

  const activeSlice = hovered !== null ? slices[hovered] : null;

  return (
    <div className="relative inline-flex items-center justify-center">
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={cx}
          cy={cy}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth={thickness}
          className="text-slate-100 dark:text-slate-800"
        />
        {slices.map((slice, i) => (
          <circle
            key={i}
            cx={cx}
            cy={cy}
            r={radius}
            fill="none"
            stroke={slice.color}
            strokeWidth={hovered === i ? thickness + 6 : thickness}
            strokeDasharray={`${slice.dashLength} ${slice.dashGap}`}
            strokeDashoffset={slice.dashOffset}
            strokeLinecap="butt"
            className="transition-all duration-300 cursor-pointer"
            style={{ opacity: hovered === null || hovered === i ? 1 : 0.4 }}
            onMouseEnter={() => setHovered(i)}
            onMouseLeave={() => setHovered(null)}
          />
        ))}
      </svg>
      {(centerLabel || centerValue) && (
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          {activeSlice ? (
            <>
              <span className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-0.5">
                {activeSlice.label}
              </span>
              <span className="text-lg font-bold text-slate-900 dark:text-white">
                {new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(activeSlice.value)}
              </span>
              <span className="text-xs text-slate-500 mt-0.5">{activeSlice.pct.toFixed(1)}%</span>
            </>
          ) : (
            <>
              {centerLabel && (
                <span className="text-xs font-medium text-slate-400 uppercase tracking-wide">
                  {centerLabel}
                </span>
              )}
              {centerValue && (
                <span className="text-xl font-bold text-slate-900 dark:text-white">{centerValue}</span>
              )}
              {centerSubValue && (
                <span className="text-xs text-slate-500 mt-0.5">{centerSubValue}</span>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}
