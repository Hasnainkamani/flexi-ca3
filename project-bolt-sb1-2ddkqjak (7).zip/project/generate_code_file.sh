#!/bin/bash
OUT="/home/project/PaisaWise_FULL_CODE.txt"
echo "PaisaWise - Smart Expense Tracker" > "$OUT"
echo "Full Project Source Code (Client + Server)" >> "$OUT"
echo "Generated: 2026-10-28" >> "$OUT"
echo "================================================" >> "$OUT"
echo "" >> "$OUT"

# Config & root files
echo "################################################" >> "$OUT"
echo "# SECTION 1: PROJECT CONFIGURATION FILES" >> "$OUT"
echo "################################################" >> "$OUT"
echo "" >> "$OUT"

for f in package.json tsconfig.json tsconfig.app.json tsconfig.node.json vite.config.ts tailwind.config.js postcss.config.js eslint.config.js index.html .gitignore README.md; do
  if [ -f "/home/project/$f" ]; then
    echo "================================================" >> "$OUT"
    echo "FILE: $f" >> "$OUT"
    echo "================================================" >> "$OUT"
    cat "/home/project/$f" >> "$OUT"
    echo "" >> "$OUT"
    echo "" >> "$OUT"
  fi
done

# Client source
echo "################################################" >> "$OUT"
echo "# SECTION 2: CLIENT-SIDE SOURCE CODE (React + TypeScript)" >> "$OUT"
echo "################################################" >> "$OUT"
echo "" >> "$OUT"

find /home/project/client/src -type f \( -name "*.tsx" -o -name "*.ts" -o -name "*.css" \) | sort | while read -r f; do
  rel=${f#/home/project/}
  echo "================================================" >> "$OUT"
  echo "FILE: $rel" >> "$OUT"
  echo "================================================" >> "$OUT"
  cat "$f" >> "$OUT"
  echo "" >> "$OUT"
  echo "" >> "$OUT"
done

# Server / MongoDB
echo "################################################" >> "$OUT"
echo "# SECTION 3: SERVER-SIDE CODE (Node.js / Express / MongoDB)" >> "$OUT"
echo "################################################" >> "$OUT"
echo "" >> "$OUT"

find /home/project/server -type f \( -name "*.ts" -o -name "*.js" \) | sort | while read -r f; do
  rel=${f#/home/project/}
  echo "================================================" >> "$OUT"
  echo "FILE: $rel" >> "$OUT"
  echo "================================================" >> "$OUT"
  cat "$f" >> "$OUT"
  echo "" >> "$OUT"
  echo "" >> "$OUT"
done

# Env template
echo "################################################" >> "$OUT"
echo "# SECTION 4: ENVIRONMENT VARIABLES (Template)" >> "$OUT"
echo "################################################" >> "$OUT"
echo "" >> "$OUT"
echo "================================================" >> "$OUT"
echo "FILE: .env (TEMPLATE - do not commit real values)" >> "$OUT"
echo "================================================" >> "$OUT"
echo "# MongoDB local connection (default: mongodb://127.0.0.1:27017)" >> "$OUT"
echo "MONGODB_URI=mongodb://127.0.0.1:27017" >> "$OUT"
echo "MONGODB_DB=paisawise" >> "$OUT"
echo "# Change this to a long random string in production" >> "$OUT"
echo "JWT_SECRET=paisawise-local-development-secret" >> "$OUT"
echo "PORT=3001" >> "$OUT"
echo "" >> "$OUT"

echo "" >> "$OUT"
echo "================================================" >> "$OUT"
echo "END OF FILE - PaisaWise Full Source Code" >> "$OUT"
echo "================================================" >> "$OUT"

wc -l "$OUT"
echo "Done"
