import { useState } from 'react';
import { api } from '@/lib/api';
import { useAuth } from '@/context/AuthContext';
import type { SavingsGoal } from '@/lib/types';
import { formatCurrency, formatDate } from '@/lib/format';
import { Modal } from '@/components/Modal';
import { Plus, Trash2, Pencil, Target, TrendingUp, CheckCircle2, Sparkles } from 'lucide-react';

interface SavingsGoalsProps {
  goals: SavingsGoal[];
  loading: boolean;
  onReload: () => Promise<void>;
}

const COLOR_PRESETS = [
  '#10b981', '#14b8a6', '#06b6d4', '#3b82f6', '#6366f1',
  '#8b5cf6', '#ec4899', '#f43f5e', '#f97316', '#f59e0b', '#84cc16',
];

interface FormState {
  name: string;
  target_amount: string;
  current_amount: string;
  target_date: string;
  color: string;
}

const EMPTY_FORM: FormState = {
  name: '',
  target_amount: '',
  current_amount: '0',
  target_date: '',
  color: '#10b981',
};

export function SavingsGoals({ goals, loading, onReload }: SavingsGoalsProps) {
  const { user } = useAuth();
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<SavingsGoal | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<SavingsGoal | null>(null);
  const [contributeTo, setContributeTo] = useState<SavingsGoal | null>(null);
  const [contribution, setContribution] = useState('');

  function openAdd() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setModalOpen(true);
  }

  function openEdit(g: SavingsGoal) {
    setEditing(g);
    setForm({
      name: g.name,
      target_amount: String(g.target_amount),
      current_amount: String(g.current_amount),
      target_date: g.target_date ?? '',
      color: g.color,
    });
    setModalOpen(true);
  }

  async function handleSave() {
    if (!user || !form.name.trim() || !form.target_amount) return;
    setSaving(true);
    const payload = {
      name: form.name.trim(),
      target_amount: parseFloat(form.target_amount),
      current_amount: parseFloat(form.current_amount || '0'),
      target_date: form.target_date || null,
      color: form.color,
      completed: parseFloat(form.current_amount || '0') >= parseFloat(form.target_amount),
    };
    if (editing) {
      await api.update('savings_goals', editing.id, {
        name: payload.name,
        target_amount: payload.target_amount,
        current_amount: payload.current_amount,
        target_date: payload.target_date,
        color: payload.color,
        completed: payload.completed,
      });
    } else {
      await api.create('savings_goals', payload);
    }
    setSaving(false);
    setModalOpen(false);
    await onReload();
  }

  async function handleContribute() {
    if (!contributeTo || !contribution) return;
    const newAmount = Number(contributeTo.current_amount) + parseFloat(contribution);
    await api.update('savings_goals', contributeTo.id, {
      current_amount: newAmount,
      completed: newAmount >= Number(contributeTo.target_amount),
    });
    setContributeTo(null);
    setContribution('');
    await onReload();
  }

  async function handleDelete() {
    if (!confirmDelete) return;
    await api.remove('savings_goals', confirmDelete.id);
    setConfirmDelete(null);
    await onReload();
  }

  const totalSaved = goals.reduce((sum, g) => sum + Number(g.current_amount), 0);
  const totalTarget = goals.reduce((sum, g) => sum + Number(g.target_amount), 0);
  const completedCount = goals.filter((g) => g.completed).length;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Savings Goals</h1>
          <p className="text-slate-500 text-sm mt-1">Track progress toward your financial dreams.</p>
        </div>
        <button onClick={openAdd} className="btn-primary">
          <Plus size={18} /> New Goal
        </button>
      </div>

      {/* Summary */}
      {goals.length > 0 && (
        <div className="grid grid-cols-3 gap-4">
          <div className="card p-5">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                <TrendingUp size={16} className="text-emerald-600" />
              </div>
              <span className="text-sm text-slate-600">Total Saved</span>
            </div>
            <p className="text-2xl font-bold text-slate-900">{formatCurrency(totalSaved)}</p>
          </div>
          <div className="card p-5">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
                <Target size={16} className="text-blue-600" />
              </div>
              <span className="text-sm text-slate-600">Total Target</span>
            </div>
            <p className="text-2xl font-bold text-slate-900">{formatCurrency(totalTarget)}</p>
          </div>
          <div className="card p-5">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center">
                <CheckCircle2 size={16} className="text-amber-600" />
              </div>
              <span className="text-sm text-slate-600">Completed</span>
            </div>
            <p className="text-2xl font-bold text-slate-900">{completedCount}/{goals.length}</p>
          </div>
        </div>
      )}

      {/* Goal cards */}
      {loading ? (
        <div className="card p-12 text-center text-slate-400 text-sm">Loading…</div>
      ) : goals.length === 0 ? (
        <div className="card p-12 text-center">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto mb-4">
            <Target size={26} className="text-slate-400" />
          </div>
          <p className="text-slate-400 text-sm mb-4">No savings goals yet.</p>
          <button onClick={openAdd} className="btn-primary inline-flex">
            <Plus size={18} /> Create your first goal
          </button>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {goals.map((g) => {
            const pct = Math.min((Number(g.current_amount) / Number(g.target_amount)) * 100, 100);
            const remaining = Number(g.target_amount) - Number(g.current_amount);
            return (
              <div key={g.id} className="card p-5 group relative overflow-hidden">
                {g.completed && (
                  <div className="absolute top-3 right-3 flex items-center gap-1 px-2 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs font-semibold">
                    <Sparkles size={12} /> Done
                  </div>
                )}
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center text-white"
                    style={{ backgroundColor: g.color }}
                  >
                    <Target size={20} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">{g.name}</p>
                    {g.target_date && (
                      <p className="text-xs text-slate-500">By {formatDate(g.target_date)}</p>
                    )}
                  </div>
                </div>

                <div className="mb-2">
                  <div className="flex items-baseline justify-between mb-2">
                    <span className="text-xl font-bold text-slate-900">
                      {formatCurrency(Number(g.current_amount))}
                    </span>
                    <span className="text-sm text-slate-500">of {formatCurrency(Number(g.target_amount))}</span>
                  </div>
                  <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${pct}%`, backgroundColor: g.color }}
                    />
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs font-medium text-slate-600">{pct.toFixed(0)}% saved</span>
                    {!g.completed && remaining > 0 && (
                      <span className="text-xs text-slate-500">{formatCurrency(remaining)} to go</span>
                    )}
                  </div>
                </div>

                <div className="flex gap-2 mt-4">
                  <button
                    onClick={() => { setContributeTo(g); setContribution(''); }}
                    className="btn-secondary flex-1 !py-2 text-xs"
                  >
                    <Plus size={14} /> Add Funds
                  </button>
                  <button
                    onClick={() => openEdit(g)}
                    className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                  >
                    <Pencil size={15} />
                  </button>
                  <button
                    onClick={() => setConfirmDelete(g)}
                    className="p-2 rounded-xl text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add/Edit modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Goal' : 'New Savings Goal'}>
        <div className="space-y-4">
          <div>
            <label className="label">Goal Name</label>
            <input
              type="text"
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="e.g. Emergency Fund"
              className="input"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Target Amount</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-medium">₹</span>
                <input
                  type="number" step="0.01" min="0" required
                  value={form.target_amount}
                  onChange={(e) => setForm({ ...form, target_amount: e.target.value })}
                  placeholder="5000.00"
                  className="input pl-8"
                />
              </div>
            </div>
            <div>
              <label className="label">Already Saved</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-medium">₹</span>
                <input
                  type="number" step="0.01" min="0"
                  value={form.current_amount}
                  onChange={(e) => setForm({ ...form, current_amount: e.target.value })}
                  placeholder="0.00"
                  className="input pl-8"
                />
              </div>
            </div>
          </div>
          <div>
            <label className="label">Target Date (optional)</label>
            <input
              type="date"
              value={form.target_date}
              onChange={(e) => setForm({ ...form, target_date: e.target.value })}
              className="input cursor-pointer"
            />
          </div>
          <div>
            <label className="label">Color</label>
            <div className="flex flex-wrap gap-2">
              {COLOR_PRESETS.map((color) => (
                <button
                  key={color}
                  onClick={() => setForm({ ...form, color })}
                  className="w-8 h-8 rounded-lg transition-all hover:scale-110"
                  style={{
                    backgroundColor: color,
                    outline: form.color === color ? '3px solid #0f172a' : 'none',
                    outlineOffset: '2px',
                  }}
                />
              ))}
            </div>
          </div>
          <button onClick={handleSave} disabled={saving} className="btn-primary w-full">
            {saving ? 'Saving…' : editing ? 'Save changes' : 'Create goal'}
          </button>
        </div>
      </Modal>

      {/* Contribute modal */}
      <Modal open={!!contributeTo} onClose={() => setContributeTo(null)} title="Add Funds">
        <div className="space-y-4">
          <p className="text-sm text-slate-600">
            Add money to <span className="font-semibold text-slate-900">{contributeTo?.name}</span>
          </p>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-medium">₹</span>
            <input
              type="number" step="0.01" min="0" autoFocus
              value={contribution}
              onChange={(e) => setContribution(e.target.value)}
              placeholder="0.00"
              className="input pl-8"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            {[50, 100, 250, 500].map((amt) => (
              <button
                key={amt}
                onClick={() => setContribution(String(amt))}
                className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-sm font-medium text-slate-700 transition-colors"
              >
                +₹{amt}
              </button>
            ))}
          </div>
          <button onClick={handleContribute} className="btn-primary w-full">
            <Plus size={18} /> Add Funds
          </button>
        </div>
      </Modal>

      {/* Delete confirm */}
      <Modal open={!!confirmDelete} onClose={() => setConfirmDelete(null)} title="Delete Goal">
        <div className="space-y-4">
          <p className="text-sm text-slate-600">
            Delete <span className="font-semibold text-slate-900">{confirmDelete?.name}</span>? This can't be undone.
          </p>
          <div className="flex gap-3">
            <button onClick={() => setConfirmDelete(null)} className="btn-secondary flex-1">Cancel</button>
            <button onClick={handleDelete} className="btn-danger flex-1">
              <Trash2 size={16} /> Delete
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
