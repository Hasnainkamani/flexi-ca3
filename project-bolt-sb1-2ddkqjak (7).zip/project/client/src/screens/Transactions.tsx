import { useMemo, useState } from 'react';
import { api } from '@/lib/api';
import { useAuth } from '@/context/AuthContext';
import type { Category, Transaction, TransactionType } from '@/lib/types';
import { formatCurrency, formatDate, todayISO } from '@/lib/format';
import { Modal } from '@/components/Modal';
import { exportTransactionsCSV } from '@/lib/csv';
import { Plus, Trash2, Pencil, Search, Filter, ArrowDownUp, Download } from 'lucide-react';

interface TransactionsProps {
  categories: Category[];
  transactions: Transaction[];
  loading: boolean;
  onReload: () => Promise<void>;
}

interface FormState {
  amount: string;
  type: TransactionType;
  category_id: string;
  description: string;
  date: string;
}

const EMPTY_FORM: FormState = {
  amount: '',
  type: 'expense',
  category_id: '',
  description: '',
  date: todayISO(),
};

export function Transactions({ categories, transactions, loading, onReload }: TransactionsProps) {
  const { user } = useAuth();
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Transaction | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<'all' | TransactionType>('all');
  const [filterCat, setFilterCat] = useState('all');
  const [sortBy, setSortBy] = useState<'date-desc' | 'date-asc' | 'amount-desc' | 'amount-asc'>('date-desc');

  const filtered = useMemo(() => {
    let result = [...transactions];
    if (search) {
      const q = search.toLowerCase();
      result = result.filter((t) =>
        (t.description ?? '').toLowerCase().includes(q) ||
        (t.category?.name ?? '').toLowerCase().includes(q)
      );
    }
    if (filterType !== 'all') result = result.filter((t) => t.type === filterType);
    if (filterCat !== 'all') result = result.filter((t) => t.category_id === filterCat);

    result.sort((a, b) => {
      switch (sortBy) {
        case 'date-asc': return a.date.localeCompare(b.date);
        case 'amount-desc': return Number(b.amount) - Number(a.amount);
        case 'amount-asc': return Number(a.amount) - Number(b.amount);
        default: return b.date.localeCompare(a.date);
      }
    });
    return result;
  }, [transactions, search, filterType, filterCat, sortBy]);

  function openAdd() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setModalOpen(true);
  }

  function openEdit(t: Transaction) {
    setEditing(t);
    setForm({
      amount: String(t.amount),
      type: t.type,
      category_id: t.category_id ?? '',
      description: t.description ?? '',
      date: t.date,
    });
    setModalOpen(true);
  }

  async function handleSave() {
    if (!user || !form.amount || !form.date) return;
    setSaving(true);
    const payload = {
      amount: parseFloat(form.amount),
      type: form.type,
      category_id: form.category_id || null,
      description: form.description || null,
      date: form.date,
    };
    if (editing) {
      await api.update('transactions', editing.id, payload);
    } else {
      await api.create('transactions', payload);
    }
    setSaving(false);
    setModalOpen(false);
    await onReload();
  }

  async function handleDelete(id: string) {
    await api.remove('transactions', id);
    await onReload();
  }

  const availableCategories = categories.filter((c) => c.type === form.type);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Transactions</h1>
          <p className="text-slate-500 text-sm mt-1">All your income and expense records.</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => exportTransactionsCSV(filtered)}
            disabled={filtered.length === 0}
            className="btn-secondary"
          >
            <Download size={18} /> Export
          </button>
          <button onClick={openAdd} className="btn-primary">
            <Plus size={18} /> Add Transaction
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search description or category…"
              className="input pl-11"
            />
          </div>
          <div className="flex gap-3">
            <div className="relative">
              <Filter size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value as 'all' | TransactionType)}
                className="input pl-9 !py-2.5 appearance-none cursor-pointer min-w-[7rem]"
              >
                <option value="all">All types</option>
                <option value="income">Income</option>
                <option value="expense">Expense</option>
              </select>
            </div>
            <select
              value={filterCat}
              onChange={(e) => setFilterCat(e.target.value)}
              className="input !py-2.5 appearance-none cursor-pointer min-w-[8rem]"
            >
              <option value="all">All categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
            <div className="relative">
              <ArrowDownUp size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                className="input pl-9 !py-2.5 appearance-none cursor-pointer min-w-[7rem]"
              >
                <option value="date-desc">Newest</option>
                <option value="date-asc">Oldest</option>
                <option value="amount-desc">High → Low</option>
                <option value="amount-asc">Low → High</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* List */}
      <div className="card overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-400 text-sm">Loading…</div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-slate-400 text-sm mb-4">No transactions found.</p>
            <button onClick={openAdd} className="btn-primary inline-flex">
              <Plus size={18} /> Add your first transaction
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filtered.map((t) => {
              const cat = t.category ?? categories.find((c) => c.id === t.category_id);
              return (
                <div
                  key={t.id}
                  className="flex items-center justify-between px-5 py-4 hover:bg-slate-50/50 transition-colors group"
                >
                  <div className="flex items-center gap-4 min-w-0">
                    <div
                      className="w-11 h-11 rounded-xl flex items-center justify-center text-white font-semibold shrink-0"
                      style={{ backgroundColor: cat?.color ?? '#94a3b8' }}
                    >
                      {(cat?.name ?? '?')[0]}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-900 truncate">
                        {t.description ?? cat?.name ?? 'Transaction'}
                      </p>
                      <div className="flex items-center gap-2 text-xs text-slate-500">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 font-medium">
                          {cat?.name ?? 'Uncategorized'}
                        </span>
                        <span>{formatDate(t.date)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`text-sm font-bold mr-3 ${t.type === 'income' ? 'text-emerald-600' : 'text-slate-900'}`}
                    >
                      {t.type === 'income' ? '+' : '-'}{formatCurrency(Number(t.amount))}
                    </span>
                    <button
                      onClick={() => openEdit(t)}
                      className="p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Pencil size={16} />
                    </button>
                    <button
                      onClick={() => handleDelete(t.id)}
                      className="p-2 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Transaction' : 'Add Transaction'}
      >
        <div className="space-y-4">
          {/* Type toggle */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl">
            <button
              onClick={() => { setForm({ ...form, type: 'expense', category_id: '' }); }}
              className={`py-2.5 rounded-lg text-sm font-semibold transition-all ${
                form.type === 'expense' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-500'
              }`}
            >
              Expense
            </button>
            <button
              onClick={() => { setForm({ ...form, type: 'income', category_id: '' }); }}
              className={`py-2.5 rounded-lg text-sm font-semibold transition-all ${
                form.type === 'income' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500'
              }`}
            >
              Income
            </button>
          </div>

          <div>
            <label className="label">Amount</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-medium">₹</span>
              <input
                type="number"
                step="0.01"
                min="0"
                required
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
                placeholder="0.00"
                className="input pl-8"
              />
            </div>
          </div>

          <div>
            <label className="label">Category</label>
            <select
              value={form.category_id}
              onChange={(e) => setForm({ ...form, category_id: e.target.value })}
              className="input cursor-pointer"
            >
              <option value="">Uncategorized</option>
              {availableCategories.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="label">Description (optional)</label>
            <input
              type="text"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="e.g. Coffee at Starbucks"
              className="input"
            />
          </div>

          <div>
            <label className="label">Date</label>
            <input
              type="date"
              required
              value={form.date}
              onChange={(e) => setForm({ ...form, date: e.target.value })}
              className="input cursor-pointer"
            />
          </div>

          <button onClick={handleSave} disabled={saving} className="btn-primary w-full">
            {saving ? 'Saving…' : editing ? 'Save changes' : 'Add transaction'}
          </button>
        </div>
      </Modal>
    </div>
  );
}
