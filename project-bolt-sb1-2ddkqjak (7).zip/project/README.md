# PaisaWise — Smart Expense Tracker

A full-stack personal finance app to track income, monitor expenses, set budgets, chase savings goals, and visualize where every rupee goes — all in a beautiful, secure dashboard. The app uses a local MongoDB database that can be viewed in MongoDB Compass.

## Features

- **Dashboard** — Gradient balance card with sparkline, income/expense stat cards with 6-month trends, interactive donut chart, smooth cash-flow line chart, daily spending bars, and smart insights (savings health, top category, month-over-month comparison)
- **Transactions** — Add, edit, delete, search, filter, and sort income/expense entries. Export to CSV.
- **Analytics** — Full-year view with income vs. expense bar chart, category breakdown donut, ranked top-categories list, month-over-month trend cards, savings rate, average transaction size, and best savings month highlight
- **Budgets** — Set monthly per-category spending limits with progress bars, over-budget alerts, and an overall month summary
- **Savings Goals** — Create financial goals with targets, target dates, and progress tracking. Quick-add funds with preset amounts.
- **Categories** — Custom income/expense categories with color picker. 11 default categories auto-seeded for new users.
- **Dark Mode** — Toggle between light and dark themes; saved to localStorage
- **Landing Page** — Marketing page with hero, feature grid, animated showcase, and call-to-action
- **Authentication** — Email/password sign-up and sign-in with server-side password hashing and tokens
- **Security** — Every database request is authenticated and filtered to the signed-in user on the server

## Tech Stack

- **Frontend:** React 18, TypeScript, Vite, Tailwind CSS, Lucide Icons
- **Backend:** Node.js, Express, MongoDB, JWT authentication
- **Database viewer:** MongoDB Compass
- **Charts:** Custom SVG components (Donut, Line, Bar, Sparkline) — no chart library

## Getting Started

### Prerequisites

- Node.js 18+
- MongoDB Community Server running locally
- MongoDB Compass (optional, for viewing the data)

### Installation

```bash
npm install
```

### Database Setup

Start your local MongoDB service. The backend connects to `mongodb://127.0.0.1:27017` and stores the app data in a database named `paisawise`. Open MongoDB Compass and connect using the same address to view the `users`, `categories`, `transactions`, `budgets`, and `savings_goals` collections.

Optional backend settings:

```env
MONGODB_URI=mongodb://127.0.0.1:27017
MONGODB_DB=paisawise
JWT_SECRET=replace-with-a-long-random-value
```

### Run

Start the API and frontend in separate terminals:

```bash
npm run server
npm run dev
```

### Build

```bash
npm run build
```

## Project Structure

```
client/
└── src/
    ├── components/    # Reusable UI: DonutChart, LineChart, BarChart, Sparkline, Modal, Layout
    ├── context/       # React contexts: AuthContext, ThemeContext
    ├── hooks/         # useData hook for fetching categories, transactions, budgets, goals
    ├── lib/           # Utilities: API client, formatters, CSV export, types, seed data
    ├── screens/       # Page components: Dashboard, Transactions, Analytics, Budgets, SavingsGoals, Categories, AuthScreen, LandingPage
    ├── App.tsx        # Root component with routing
    ├── main.tsx       # Entry point
    └── index.css      # Global styles + Tailwind
server/
└── index.ts           # Express API, MongoDB connection, authentication, and data routes
```

## Database Collections

Data is stored in MongoDB. Each collection stores documents per user; the server filters every query by the signed-in user's id.

### users
| Field | Type | Description |
|-------|------|-------------|
| _id | ObjectId | Primary key |
| email | string | Unique, lowercased email |
| passwordHash | string | bcrypt hash (never returned to the client) |
| createdAt | Date | Account creation timestamp |

### categories
| Field | Type | Description |
|-------|------|-------------|
| _id | ObjectId | Primary key |
| user_id | string | Owner (references users._id) |
| name | string | Category name |
| type | string | 'income' or 'expense' |
| color | string | Hex color for UI |
| icon | string | Lucide icon name |
| created_at | string | ISO creation timestamp |

### transactions
| Field | Type | Description |
|-------|------|-------------|
| _id | ObjectId | Primary key |
| user_id | string | Owner (references users._id) |
| amount | number | Transaction amount (> 0) |
| type | string | 'income' or 'expense' |
| category_id | string | References categories._id (nullable) |
| description | string | Optional description |
| date | string | Transaction date (YYYY-MM-DD) |
| created_at | string | ISO creation timestamp |

### budgets
| Field | Type | Description |
|-------|------|-------------|
| _id | ObjectId | Primary key |
| user_id | string | Owner (references users._id) |
| category_id | string | References categories._id |
| amount | number | Monthly limit |
| month | string | First of month (YYYY-MM-01) |
| created_at | string | ISO creation timestamp |

### savings_goals
| Field | Type | Description |
|-------|------|-------------|
| _id | ObjectId | Primary key |
| user_id | string | Owner (references users._id) |
| name | string | Goal name |
| target_amount | number | Target amount |
| current_amount | number | Amount saved so far |
| target_date | string | Optional deadline (YYYY-MM-DD) |
| color | string | Hex color |
| completed | boolean | Auto-set when target reached |
| created_at | string | ISO creation timestamp |

## License

MIT
