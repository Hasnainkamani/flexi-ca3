import { useMemo, useState } from 'react';
import { api } from '@/lib/api';
import { useAuth } from '@/context/AuthContext';
import type { Budget, Category, Transaction } from '@/lib/types';
import { formatCurrency, formatMonth, monthKey } from '@/lib/format';
import { Modal } from '@/components/Modal';
import { Plus, Pencil, Trash2, Target, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface BudgetsProps {
  categories: Category[];
  transactions: Transaction[];
  budgets: Budget[];
  loading: boolean;
  onReload: () => Promise<void>;
}

interface FormState {
  category_id: string;
  amount: string;
  month: string;
}

export function Budgets({ categories, transactions, budgets, loading, onReload }: BudgetsProps) {
  const { user } = useAuth();
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Budget | null>(null);
  const [form, setForm] = useState<FormState>({ category_id: '', amount: '', month: monthKey(new Date()) });
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<Budget | null>(null);
  const [month, setMonth] = useState(() => new Date());

  const expenseCategories = useMemo(() => categories.filter((c) => c.type === 'expense'), [categories]);

  const monthBudgets = useMemo(() => {
    const key = monthKey(month);
    return budgets.filter((b) => b.month === key);
  }, [budgets, month]);

  const spendByCategory = useMemo(() => {
    const map = new Map<string, number>();
    for (const t of transactions) {
      if (t.type !== 'expense' || !t.category_id) continue;
      const d = new Date(t.date + 'T00:00:00');
      if (d.getFullYear() === month.getFullYear() && d.getMonth() === month.getMonth()) {
        map.set(t.category_id, (map.get(t.category_id) ?? 0) + Number(t.amount));
      }
    }
    return map;
  }, [transactions, month]);

  const totalBudget = monthBudgets.reduce((sum, b) => sum + Number(b.amount), 0);
  const totalSpent = monthBudgets.reduce((sum, b) => sum + (spendByCategory.get(b.category_id) ?? 0), 0);

  function openAdd() {
    setEditing(null);
    setForm({ category_id: '', amount: '', month: monthKey(month) });
    setModalOpen(true);
  }

  function openEdit(b: Budget) {
    setEditing(b);
    setForm({ category_id: b.category_id, amount: String(b.amount), month: b.month });
    setModalOpen(true);
  }

  async function handleSave() {
    if (!user || !form.category_id || !form.amount) return;
    setSaving(true);
    const payload = {
      category_id: form.category_id,
      amount: parseFloat(form.amount),
      month: form.month,
    };
    if (editing) {
      await api.update('budgets', editing.id, { amount: parseFloat(form.amount) });
    } else {
      await api.create('budgets', payload);
    }
    setSaving(false);
    setModalOpen(false);
    await onReload();
  }

  async function handleDelete() {
    if (!confirmDelete) return;
    await api.remove('budgets', confirmDelete.id);
    setConfirmDelete(null);
    await onReload();
  }

  const prevMonth = () => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1));
  const nextMonth = () => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1));

  const overallPct = totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0;
  const overallStatus =
    overallPct >= 100 ? 'over' : overallPct >= 80 ? 'warning' : 'ok';

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Budgets</h1>
          <p className="text-slate-500 text-sm mt-1">Set monthly spending limits per category.</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={prevMonth} className="btn-secondary !p-2.5">‹</button>
          <span className="px-4 py-2.5 text-sm font-semibold text-slate-700 min-w-[10rem] text-center">
            {formatMonth(monthKey(month))}
          </span>
          <button onClick={nextMonth} className="btn-secondary !p-2.5">›</button>
          <button onClick={openAdd} className="btn-primary ml-2">
            <Plus size={18} /> Add Budget
          </button>
        </div>
      </div>

      {/* Overall progress */}
      {monthBudgets.length > 0 && (
        <div className="card p-6">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                overallStatus === 'over' ? 'bg-red-100 text-red-600'
                  : overallStatus === 'warning' ? 'bg-amber-100 text-amber-600'
                  : 'bg-emerald-100 text-emerald-600'
              }`}>
                {overallStatus === 'over' ? <AlertTriangle size={20} /> : <Target size={20} />}
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-900">Total Budget</p>
                <p className="text-xs text-slate-500">{formatCurrency(totalSpent)} of {formatCurrency(totalBudget)} spent</p>
              </div>
            </div>
            <span className={`text-2xl font-bold ${
              overallStatus === 'over' ? 'text-red-600'
                : overallStatus === 'warning' ? 'text-amber-600'
                : 'text-emerald-600'
            }`}>
              {overallPct.toFixed(0)}%
            </span>
          </div>
          <div className="h-3 rounded-full bg-slate-100 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                overallStatus === 'over' ? 'bg-red-500'
                  : overallStatus === 'warning' ? 'bg-amber-500'
                  : 'bg-emerald-500'
              }`}
              style={{ width: `${Math.min(overallPct, 100)}%` }}
            />
          </div>
        </div>
      )}

      {/* Budget cards */}
      {loading ? (
        <div className="card p-12 text-center text-slate-400 text-sm">Loading…</div>
      ) : monthBudgets.length === 0 ? (
        <div className="card p-12 text-center">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto mb-4">
            <Target size={26} className="text-slate-400" />
          </div>
          <p className="text-slate-400 text-sm mb-4">No budgets set for this month yet.</p>
          <button onClick={openAdd} className="btn-primary inline-flex">
            <Plus size={18} /> Set your first budget
          </button>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {monthBudgets.map((b) => {
            const cat = b.category ?? categories.find((c) => c.id === b.category_id);
            const spent = spendByCategory.get(b.category_id) ?? 0;
            const pct = (spent / Number(b.amount)) * 100;
            const remaining = Number(b.amount) - spent;
            const status = pct >= 100 ? 'over' : pct >= 80 ? 'warning' : 'ok';

            return (
              <div key={b.id} className="card p-5 group">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-sm font-semibold"
                      style={{ backgroundColor: cat?.color ?? '#94a3b8' }}
                    >
                      {(cat?.name ?? '?')[0]}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-900">{cat?.name ?? 'Unknown'}</p>
                      <p className="text-xs text-slate-500">Budget {formatCurrency(Number(b.amount))}</p>
                    </div>
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => openEdit(b)}
                      className="p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                    >
                      <Pencil size={15} />
                    </button>
                    <button
                      onClick={() => setConfirmDelete(b)}
                      className="p-2 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-slate-500">
                    {formatCurrency(spent)} spent
                  </span>
                  <span className={`text-xs font-semibold ${
                    remaining < 0 ? 'text-red-600' : 'text-emerald-600'
                  }`}>
                    {remaining >= 0
                      ? `${formatCurrency(remaining)} left`
                      : `${formatCurrency(Math.abs(remaining))} over`}
                  </span>
                </div>

                <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      status === 'over' ? 'bg-red-500'
                        : status === 'warning' ? 'bg-amber-500'
                        : 'bg-emerald-500'
                    }`}
                    style={{ width: `${Math.min(pct, 100)}%` }}
                  />
                </div>

                <div className="flex items-center justify-between mt-3">
                  <span className="text-xs font-medium text-slate-600">{pct.toFixed(0)}% used</span>
                  {status === 'over' ? (
                    <span className="flex items-center gap-1 text-xs font-medium text-red-600">
                      <AlertTriangle size={12} /> Over budget
                    </span>
                  ) : status === 'warning' ? (
                    <span className="flex items-center gap-1 text-xs font-medium text-amber-600">
                      <AlertTriangle size={12} /> Almost there
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-xs font-medium text-emerald-600">
                      <CheckCircle2 size={12} /> On track
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add/Edit modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Budget' : 'Add Budget'}
      >
        <div className="space-y-4">
          <div>
            <label className="label">Category</label>
            <select
              value={form.category_id}
              onChange={(e) => setForm({ ...form, category_id: e.target.value })}
              className="input cursor-pointer"
              disabled={!!editing}
            >
              <option value="">Select a category</option>
              {expenseCategories.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="label">Monthly Limit</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-medium">₹</span>
              <input
                type="number"
                step="0.01"
                min="0"
                required
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
                placeholder="0.00"
                className="input pl-8"
              />
            </div>
          </div>

          <div>
            <label className="label">Month</label>
            <input
              type="month"
              required
              value={form.month.slice(0, 7)}
              onChange={(e) => setForm({ ...form, month: `${e.target.value}-01` })}
              className="input cursor-pointer"
              disabled={!!editing}
            />
          </div>

          <button onClick={handleSave} disabled={saving} className="btn-primary w-full">
            {saving ? 'Saving…' : editing ? 'Save changes' : 'Add budget'}
          </button>
        </div>
      </Modal>

      {/* Delete confirm */}
      <Modal open={!!confirmDelete} onClose={() => setConfirmDelete(null)} title="Delete Budget">
        <div className="space-y-4">
          <p className="text-sm text-slate-600">
            Remove the budget for{' '}
            <span className="font-semibold text-slate-900">
              {confirmDelete?.category?.name ?? categories.find((c) => c.id === confirmDelete?.category_id)?.name}
            </span>
            ?
          </p>
          <div className="flex gap-3">
            <button onClick={() => setConfirmDelete(null)} className="btn-secondary flex-1">Cancel</button>
            <button onClick={handleDelete} className="btn-danger flex-1">
              <Trash2 size={16} /> Delete
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
