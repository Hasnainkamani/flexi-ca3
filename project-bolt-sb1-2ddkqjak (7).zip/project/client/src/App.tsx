import { useState } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { ThemeProvider } from '@/context/ThemeContext';
import { Layout, type PageId } from '@/components/Layout';
import { AuthScreen } from '@/screens/AuthScreen';
import { LandingPage } from '@/screens/LandingPage';
import { Dashboard } from '@/screens/Dashboard';
import { Transactions } from '@/screens/Transactions';
import { Categories } from '@/screens/Categories';
import { Budgets } from '@/screens/Budgets';
import { SavingsGoals } from '@/screens/SavingsGoals';
import { Analytics } from '@/screens/Analytics';
import { useData } from '@/hooks/useData';

type AuthView = 'landing' | 'auth';

function AppContent() {
  const { user, loading } = useAuth();
  const [page, setPage] = useState<PageId>('dashboard');
  const [authView, setAuthView] = useState<AuthView>('landing');

  const data = useData(user?.id);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950">
        <div className="w-10 h-10 border-4 border-emerald-200 border-t-emerald-600 rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    if (authView === 'landing') {
      return <LandingPage onGetStarted={() => setAuthView('auth')} />;
    }
    return <AuthScreen />;
  }

  return (
    <Layout current={page} onNavigate={setPage}>
      {page === 'dashboard' && (
        <Dashboard
          categories={data.categories}
          transactions={data.transactions}
          loading={data.loading}
        />
      )}
      {page === 'transactions' && (
        <Transactions
          categories={data.categories}
          transactions={data.transactions}
          loading={data.loading}
          onReload={data.reload}
        />
      )}
      {page === 'analytics' && (
        <Analytics
          categories={data.categories}
          transactions={data.transactions}
          loading={data.loading}
        />
      )}
      {page === 'budgets' && (
        <Budgets
          categories={data.categories}
          transactions={data.transactions}
          budgets={data.budgets}
          loading={data.loading}
          onReload={data.reload}
        />
      )}
      {page === 'goals' && (
        <SavingsGoals
          goals={data.goals}
          loading={data.loading}
          onReload={data.reload}
        />
      )}
      {page === 'categories' && (
        <Categories
          categories={data.categories}
          loading={data.loading}
          onReload={data.reload}
        />
      )}
    </Layout>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}
