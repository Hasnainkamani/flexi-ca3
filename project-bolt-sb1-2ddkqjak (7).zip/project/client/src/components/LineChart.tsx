interface LineChartProps {
  data: { label: string; income: number; expense: number }[];
  height?: number;
}

export function LineChart({ data, height = 220 }: LineChartProps) {
  const width = 600;
  const padding = { top: 20, right: 16, bottom: 28, left: 16 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;
  const maxVal = Math.max(...data.map((d) => Math.max(d.income, d.expense)), 100);

  const xStep = chartW / Math.max(data.length - 1, 1);

  function pointsFor(key: 'income' | 'expense') {
    return data.map((d, i) => {
      const x = padding.left + i * xStep;
      const y = padding.top + chartH - (d[key] / maxVal) * chartH;
      return { x, y };
    });
  }

  function smoothPath(pts: { x: number; y: number }[]) {
    if (pts.length < 2) return '';
    let path = `M ${pts[0].x},${pts[0].y}`;
    for (let i = 1; i < pts.length; i++) {
      const prev = pts[i - 1];
      const curr = pts[i];
      const cpx1 = prev.x + (curr.x - prev.x) / 2;
      const cpx2 = prev.x + (curr.x - prev.x) / 2;
      path += ` C ${cpx1},${prev.y} ${cpx2},${curr.y} ${curr.x},${curr.y}`;
    }
    return path;
  }

  function areaPath(pts: { x: number; y: number }[]) {
    const line = smoothPath(pts);
    if (!line) return '';
    const lastX = pts[pts.length - 1].x;
    const firstX = pts[0].x;
    const baseY = padding.top + chartH;
    return `${line} L ${lastX},${baseY} L ${firstX},${baseY} Z`;
  }

  const incomePts = pointsFor('income');
  const expensePts = pointsFor('expense');

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ height }}>
      <defs>
        <linearGradient id="incomeGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#10b981" stopOpacity="0.25" />
          <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="expenseGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.2" />
          <stop offset="100%" stopColor="#f43f5e" stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* Grid lines */}
      {[0, 0.25, 0.5, 0.75, 1].map((f) => {
        const y = padding.top + chartH * f;
        return (
          <line
            key={f}
            x1={padding.left} y1={y}
            x2={width - padding.right} y2={y}
            stroke="currentColor"
            strokeWidth="1"
            className="text-slate-100 dark:text-slate-800"
          />
        );
      })}

      {/* Expense area + line */}
      <path d={areaPath(expensePts)} fill="url(#expenseGrad)" />
      <path d={smoothPath(expensePts)} fill="none" stroke="#f43f5e" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />

      {/* Income area + line */}
      <path d={areaPath(incomePts)} fill="url(#incomeGrad)" />
      <path d={smoothPath(incomePts)} fill="none" stroke="#10b981" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />

      {/* Points */}
      {incomePts.map((p, i) => (
        <circle key={`i${i}`} cx={p.x} cy={p.y} r="3.5" fill="#10b981" className="drop-shadow-sm" />
      ))}
      {expensePts.map((p, i) => (
        <circle key={`e${i}`} cx={p.x} cy={p.y} r="3.5" fill="#f43f5e" className="drop-shadow-sm" />
      ))}

      {/* X labels */}
      {data.map((d, i) => (
        <text
          key={i}
          x={padding.left + i * xStep}
          y={height - 8}
          textAnchor="middle"
          className="fill-slate-400 text-[10px] font-medium"
        >
          {d.label}
        </text>
      ))}
    </svg>
  );
}
