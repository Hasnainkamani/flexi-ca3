import { type ReactNode, useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { Wallet, LayoutDashboard, Receipt, Tags, Target, TrendingUp, PiggyBank, LogOut, Menu, X, Moon, Sun, Expand, Shrink } from 'lucide-react';

export type PageId = 'dashboard' | 'transactions' | 'categories' | 'budgets' | 'goals' | 'analytics';

interface LayoutProps {
  current: PageId;
  onNavigate: (page: PageId) => void;
  children: ReactNode;
}

const NAV: { id: PageId; label: string; icon: typeof Wallet }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'transactions', label: 'Transactions', icon: Receipt },
  { id: 'analytics', label: 'Analytics', icon: TrendingUp },
  { id: 'budgets', label: 'Budgets', icon: Target },
  { id: 'goals', label: 'Savings Goals', icon: PiggyBank },
  { id: 'categories', label: 'Categories', icon: Tags },
];

export function Layout({ current, onNavigate, children }: LayoutProps) {
  const { user, signOut } = useAuth();
  const { theme, toggle } = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [presenting, setPresenting] = useState(false);

  function navigate(page: PageId) {
    onNavigate(page);
    setMobileOpen(false);
  }

  useEffect(() => {
    if (!presenting) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') setPresenting(false);
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [presenting]);

  const sidebarContent = (
    <>
      <div className="flex items-center gap-3 px-6 h-16 border-b border-white/5">
        <div className="w-9 h-9 rounded-xl bg-emerald-500 flex items-center justify-center">
          <Wallet size={20} className="text-white" />
        </div>
        <span className="text-lg font-bold text-white">PaisaWise</span>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {NAV.map((item) => {
          const Icon = item.icon;
          const active = current === item.id;
          return (
            <button
              key={item.id}
              onClick={() => navigate(item.id)}
              className={`nav-link w-full ${active ? 'nav-link-active' : 'nav-link-inactive'}`}
            >
              <Icon size={19} />
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="px-3 pb-4 border-t border-white/5 pt-4">
        {/* Presentation mode toggle */}
        <button
          onClick={() => setPresenting(true)}
          className="nav-link w-full text-slate-400 hover:text-white hover:bg-white/5 mb-2"
        >
          <Expand size={19} />
          Present
        </button>

        {/* Theme toggle */}
        <button
          onClick={toggle}
          className="nav-link w-full text-slate-400 hover:text-white hover:bg-white/5 mb-2"
        >
          {theme === 'dark' ? <Sun size={19} /> : <Moon size={19} />}
          {theme === 'dark' ? 'Light mode' : 'Dark mode'}
        </button>

        <div className="flex items-center gap-3 px-3 py-2 mb-2">
          <div className="w-9 h-9 rounded-full bg-slate-700 flex items-center justify-center text-sm font-semibold text-white">
            {(user?.email ?? 'U')[0].toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">{user?.email}</p>
            <p className="text-xs text-slate-500">Free plan</p>
          </div>
        </div>
        <button
          onClick={signOut}
          className="nav-link w-full text-slate-400 hover:text-white hover:bg-white/5"
        >
          <LogOut size={19} />
          Sign out
        </button>
      </div>
    </>
  );

  if (presenting) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 relative">
        <main className="p-6 lg:p-8 w-full">{children}</main>
        <button
          onClick={() => setPresenting(false)}
          title="Exit presentation (Esc)"
          className="fixed top-4 right-4 z-50 flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-medium bg-slate-900/80 text-white backdrop-blur-sm hover:bg-slate-900 transition-colors shadow-lg"
        >
          <Shrink size={18} />
          Exit
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      {/* Desktop sidebar */}
      <aside className="w-64 bg-slate-900 flex flex-col fixed inset-y-0 left-0 z-30 hidden lg:flex">
        {sidebarContent}
      </aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <>
          <div
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-40 lg:hidden"
            onClick={() => setMobileOpen(false)}
          />
          <aside className="fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 flex flex-col lg:hidden animate-fade-in">
            <button
              onClick={() => setMobileOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5"
            >
              <X size={20} />
            </button>
            {sidebarContent}
          </aside>
        </>
      )}

      {/* Main */}
      <div className="lg:ml-64">
        {/* Mobile top bar */}
        <div className="lg:hidden flex items-center justify-between px-4 h-14 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-20">
          <button
            onClick={() => setMobileOpen(true)}
            className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <Menu size={22} />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500 flex items-center justify-center">
              <Wallet size={16} className="text-white" />
            </div>
            <span className="font-bold text-slate-900 dark:text-white">PaisaWise</span>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPresenting(true)}
              className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <Expand size={20} />
            </button>
            <button
              onClick={toggle}
              className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </div>
        </div>

        <main className="p-6 lg:p-8 w-full">{children}</main>
      </div>
    </div>
  );
}
