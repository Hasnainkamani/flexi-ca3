import type { Budget, Category, SavingsGoal, Transaction } from '@/lib/types';

export interface AppUser {
  id: string;
  email: string;
}

const tokenKey = 'paisawise_token';

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = localStorage.getItem(tokenKey);
  const response = await fetch(`/api${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });
  if (!response.ok) {
    const body = await response.json().catch(() => null) as { error?: string } | null;
    throw new Error(body?.error ?? 'Unable to complete that request.');
  }
  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

export function saveToken(token: string): void {
  localStorage.setItem(tokenKey, token);
}

export function clearToken(): void {
  localStorage.removeItem(tokenKey);
}

export const api = {
  signUp: (email: string, password: string) => request<{ token: string; user: AppUser }>('/auth/signup', { method: 'POST', body: JSON.stringify({ email, password }) }),
  signIn: (email: string, password: string) => request<{ token: string; user: AppUser }>('/auth/signin', { method: 'POST', body: JSON.stringify({ email, password }) }),
  me: () => request<{ user: AppUser }>('/auth/me'),
  categories: () => request<Category[]>('/categories'),
  transactions: () => request<Transaction[]>('/transactions'),
  budgets: () => request<Budget[]>('/budgets'),
  goals: () => request<SavingsGoal[]>('/savings_goals'),
  create: <T>(resource: string, body: unknown) => request<T>(`/${resource}`, { method: 'POST', body: JSON.stringify(body) }),
  update: <T>(resource: string, id: string, body: unknown) => request<T>(`/${resource}/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  remove: (resource: string, id: string) => request<void>(`/${resource}/${id}`, { method: 'DELETE' }),
};
