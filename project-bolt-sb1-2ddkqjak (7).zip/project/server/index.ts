import cors from 'cors';
import express, { type NextFunction, type Request, type Response } from 'express';
import bcrypt from 'bcryptjs';
import { MongoClient, ObjectId, type Collection, type Db } from 'mongodb';
import jwt from 'jsonwebtoken';

interface UserDocument {
  _id: ObjectId;
  email: string;
  passwordHash: string;
  createdAt: Date;
}

interface AuthenticatedRequest extends Request {
  userId?: string;
}

const app = express();
const port = Number(process.env.PORT ?? 3001);
const mongoUrl = process.env.MONGODB_URI ?? 'mongodb://127.0.0.1:27017';
const databaseName = process.env.MONGODB_DB ?? 'paisawise';
const jwtSecret = process.env.JWT_SECRET ?? 'paisawise-local-development-secret';
const client = new MongoClient(mongoUrl);
let database: Db;

app.use(cors({ origin: 'http://localhost:5173' }));
app.use(express.json());

function collection(name: string): Collection {
  return database.collection(name);
}

function tokenFor(user: UserDocument): string {
  return jwt.sign({ userId: user._id.toString() }, jwtSecret, { expiresIn: '7d' });
}

function idFor(value: string): ObjectId {
  if (!ObjectId.isValid(value)) throw new Error('Invalid identifier');
  return new ObjectId(value);
}

function auth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const header = req.headers.authorization;
  const token = header?.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  try {
    const payload = jwt.verify(token, jwtSecret) as { userId: string };
    req.userId = payload.userId;
    next();
  } catch {
    res.status(401).json({ error: 'Authentication required' });
  }
}

function handleError(res: Response, error: unknown): void {
  console.error(error);
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
}

app.get('/api/health', (_req, res) => res.json({ ok: true }));

app.post('/api/auth/signup', async (req, res) => {
  try {
    const email = String(req.body.email ?? '').trim().toLowerCase();
    const password = String(req.body.password ?? '');
    if (!email || password.length < 6) {
      res.status(400).json({ error: 'Enter a valid email and a password of at least 6 characters.' });
      return;
    }

    const users = collection('users');
    const existing = await users.findOne({ email });
    if (existing) {
      res.status(400).json({ error: 'Unable to create this account. Please try signing in.' });
      return;
    }

    const user: UserDocument = {
      _id: new ObjectId(),
      email,
      passwordHash: await bcrypt.hash(password, 12),
      createdAt: new Date(),
    };
    await users.insertOne(user);
    res.status(201).json({ token: tokenFor(user), user: { id: user._id.toString(), email: user.email } });
  } catch (error) {
    handleError(res, error);
  }
});

app.post('/api/auth/signin', async (req, res) => {
  try {
    const email = String(req.body.email ?? '').trim().toLowerCase();
    const password = String(req.body.password ?? '');
    const user = await collection('users').findOne({ email }) as UserDocument | null;
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      res.status(401).json({ error: 'Email or password is incorrect.' });
      return;
    }
    res.json({ token: tokenFor(user), user: { id: user._id.toString(), email: user.email } });
  } catch (error) {
    handleError(res, error);
  }
});

app.get('/api/auth/me', auth, async (req: AuthenticatedRequest, res) => {
  try {
    const user = await collection('users').findOne({ _id: idFor(req.userId as string) }) as UserDocument | null;
    if (!user) {
      res.status(401).json({ error: 'Authentication required' });
      return;
    }
    res.json({ user: { id: user._id.toString(), email: user.email } });
  } catch (error) {
    handleError(res, error);
  }
});

const resources = ['categories', 'transactions', 'budgets', 'savings_goals'] as const;
for (const resource of resources) {
  app.get(`/api/${resource}`, auth, async (req: AuthenticatedRequest, res) => {
    try {
      const rows = await collection(resource).find({ user_id: req.userId }).sort(resource === 'categories' ? { name: 1 } : { created_at: -1 }).toArray();
      if (resource === 'transactions' || resource === 'budgets') {
        const categoryIds = rows.map((row) => row.category_id).filter(Boolean).map((id) => idFor(String(id)));
        const categories = await collection('categories').find({ _id: { $in: categoryIds }, user_id: req.userId }).toArray();
        const categoryMap = new Map(categories.map((category) => [category._id.toString(), category]));
        res.json(rows.map((row) => ({ ...row, id: row._id.toString(), category: row.category_id ? categoryMap.get(String(row.category_id)) ?? null : null })));
        return;
      }
      res.json(rows.map((row) => ({ ...row, id: row._id.toString() })));
    } catch (error) {
      handleError(res, error);
    }
  });

  app.post(`/api/${resource}`, auth, async (req: AuthenticatedRequest, res) => {
    try {
      const document = { ...req.body, _id: new ObjectId(), user_id: req.userId, created_at: new Date().toISOString() };
      delete document.id;
      await collection(resource).insertOne(document);
      res.status(201).json({ ...document, id: document._id.toString() });
    } catch (error) {
      handleError(res, error);
    }
  });

  app.patch(`/api/${resource}/:id`, auth, async (req: AuthenticatedRequest, res) => {
    try {
      const updates = { ...req.body };
      delete updates._id;
      delete updates.id;
      delete updates.user_id;
      delete updates.created_at;
      const result = await collection(resource).findOneAndUpdate(
        { _id: idFor(String(req.params.id)), user_id: req.userId },
        { $set: updates },
        { returnDocument: 'after' },
      );
      if (!result) {
        res.status(404).json({ error: 'Record not found.' });
        return;
      }
      res.json({ ...result, id: result._id.toString() });
    } catch (error) {
      handleError(res, error);
    }
  });

  app.delete(`/api/${resource}/:id`, auth, async (req: AuthenticatedRequest, res) => {
    try {
      await collection(resource).deleteOne({ _id: idFor(String(req.params.id)), user_id: req.userId });
      res.status(204).send();
    } catch (error) {
      handleError(res, error);
    }
  });
}

async function start(): Promise<void> {
  await client.connect();
  database = client.db(databaseName);
  await collection('users').createIndex({ email: 1 }, { unique: true });
  app.listen(port, () => console.log(`PaisaWise MongoDB API running on http://localhost:${port}`));
}

start().catch((error) => {
  console.error('Could not connect to MongoDB.', error);
  process.exit(1);
});
