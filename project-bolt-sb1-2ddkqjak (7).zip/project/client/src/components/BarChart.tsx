import { formatCompactCurrency } from '@/lib/format';

interface BarDatum {
  label: string;
  income: number;
  expense: number;
}

interface BarChartProps {
  data: BarDatum[];
}

export function BarChart({ data }: BarChartProps) {
  const maxVal = Math.max(
    ...data.map((d) => Math.max(d.income, d.expense)),
    100
  );

  return (
    <div>
      <div className="flex items-end justify-between gap-2 h-48">
        {data.map((d, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-2">
            <div className="w-full flex items-end justify-center gap-1 h-full">
              <div className="group relative flex-1 max-w-[28px] flex flex-col justify-end h-full">
                <div
                  className="w-full rounded-t-md bg-emerald-400 transition-all duration-500 hover:bg-emerald-500"
                  style={{
                    height: `${(d.income / maxVal) * 100}%`,
                    minHeight: d.income > 0 ? '4px' : '0',
                  }}
                />
                <div className="absolute -top-7 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900 dark:bg-slate-700 text-white text-xs px-2 py-1 rounded-md whitespace-nowrap z-10 pointer-events-none">
                  Income {formatCompactCurrency(d.income)}
                </div>
              </div>
              <div className="group relative flex-1 max-w-[28px] flex flex-col justify-end h-full">
                <div
                  className="w-full rounded-t-md bg-rose-400 transition-all duration-500 hover:bg-rose-500"
                  style={{
                    height: `${(d.expense / maxVal) * 100}%`,
                    minHeight: d.expense > 0 ? '4px' : '0',
                  }}
                />
                <div className="absolute -top-7 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900 dark:bg-slate-700 text-white text-xs px-2 py-1 rounded-md whitespace-nowrap z-10 pointer-events-none">
                  Expense {formatCompactCurrency(d.expense)}
                </div>
              </div>
            </div>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">{d.label}</span>
          </div>
        ))}
      </div>
      <div className="flex items-center justify-center gap-6 mt-4">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-sm bg-emerald-400" />
          <span className="text-xs text-slate-600 dark:text-slate-400 font-medium">Income</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-sm bg-rose-400" />
          <span className="text-xs text-slate-600 dark:text-slate-400 font-medium">Expense</span>
        </div>
      </div>
    </div>
  );
}
