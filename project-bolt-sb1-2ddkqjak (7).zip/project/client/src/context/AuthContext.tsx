import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { api, clearToken, saveToken, type AppUser } from '@/lib/api';

interface AuthContextValue {
  user: AppUser | null;
  loading: boolean;
  signUp: (email: string, password: string) => Promise<{ error: string | null }>;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.me()
      .then(({ user: currentUser }) => setUser(currentUser))
      .catch(() => clearToken())
      .finally(() => setLoading(false));
  }, []);

  async function signUp(email: string, password: string) {
    try {
      const result = await api.signUp(email, password);
      saveToken(result.token);
      setUser(result.user);
      return { error: null };
    } catch (error) {
      return { error: error instanceof Error ? error.message : 'Unable to create your account.' };
    }
  }

  async function signIn(email: string, password: string) {
    try {
      const result = await api.signIn(email, password);
      saveToken(result.token);
      setUser(result.user);
      return { error: null };
    } catch (error) {
      return { error: error instanceof Error ? error.message : 'Unable to sign in.' };
    }
  }

  async function signOut() {
    clearToken();
    setUser(null);
  }

  return <AuthContext.Provider value={{ user, loading, signUp, signIn, signOut }}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
