import { useState } from 'react';
import { api } from '@/lib/api';
import { useAuth } from '@/context/AuthContext';
import type { Category, TransactionType } from '@/lib/types';
import { Modal } from '@/components/Modal';
import { Plus, Trash2, Pencil } from 'lucide-react';

interface CategoriesProps {
  categories: Category[];
  loading: boolean;
  onReload: () => Promise<void>;
}

const COLOR_PRESETS = [
  '#10b981', '#14b8a6', '#06b6d4', '#3b82f6', '#0ea5e9',
  '#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#ef4444',
  '#f97316', '#f59e0b', '#d97706', '#84cc16', '#22c55e',
  '#64748b',
];

interface FormState {
  name: string;
  type: TransactionType;
  color: string;
  icon: string;
}

const EMPTY_FORM: FormState = { name: '', type: 'expense', color: '#10b981', icon: 'Wallet' };

export function Categories({ categories, loading, onReload }: CategoriesProps) {
  const { user } = useAuth();
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Category | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<Category | null>(null);

  function openAdd() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setModalOpen(true);
  }

  function openEdit(c: Category) {
    setEditing(c);
    setForm({ name: c.name, type: c.type, color: c.color, icon: c.icon });
    setModalOpen(true);
  }

  async function handleSave() {
    if (!user || !form.name.trim()) return;
    setSaving(true);
    const payload = { ...form };
    if (editing) {
      await api.update('categories', editing.id, { name: form.name, type: form.type, color: form.color, icon: form.icon });
    } else {
      await api.create('categories', payload);
    }
    setSaving(false);
    setModalOpen(false);
    await onReload();
  }

  async function handleDelete() {
    if (!confirmDelete) return;
    await api.remove('categories', confirmDelete.id);
    setConfirmDelete(null);
    await onReload();
  }

  const expenseCats = categories.filter((c) => c.type === 'expense');
  const incomeCats = categories.filter((c) => c.type === 'income');

  function renderGrid(items: Category[]) {
    return (
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((c) => (
          <div key={c.id} className="card p-4 group">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center text-white"
                  style={{ backgroundColor: c.color }}
                >
                  <span className="text-lg font-bold">{c.name[0]}</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-900">{c.name}</p>
                  <p className="text-xs text-slate-500 capitalize">{c.type}</p>
                </div>
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => openEdit(c)}
                  className="p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                >
                  <Pencil size={15} />
                </button>
                <button
                  onClick={() => setConfirmDelete(c)}
                  className="p-2 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Categories</h1>
          <p className="text-slate-500 text-sm mt-1">Organize your income and expenses.</p>
        </div>
        <button onClick={openAdd} className="btn-primary">
          <Plus size={18} /> Add Category
        </button>
      </div>

      {loading ? (
        <div className="card p-12 text-center text-slate-400 text-sm">Loading…</div>
      ) : (
        <div className="space-y-6">
          <div>
            <h2 className="text-sm font-semibold text-slate-700 uppercase tracking-wide mb-3">
              Expense · {expenseCats.length}
            </h2>
            {renderGrid(expenseCats)}
          </div>
          <div>
            <h2 className="text-sm font-semibold text-slate-700 uppercase tracking-wide mb-3">
              Income · {incomeCats.length}
            </h2>
            {renderGrid(incomeCats)}
          </div>
        </div>
      )}

      {/* Add/Edit modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Category' : 'Add Category'}
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl">
            <button
              onClick={() => setForm({ ...form, type: 'expense' })}
              className={`py-2.5 rounded-lg text-sm font-semibold transition-all ${
                form.type === 'expense' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-500'
              }`}
            >
              Expense
            </button>
            <button
              onClick={() => setForm({ ...form, type: 'income' })}
              className={`py-2.5 rounded-lg text-sm font-semibold transition-all ${
                form.type === 'income' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500'
              }`}
            >
              Income
            </button>
          </div>

          <div>
            <label className="label">Name</label>
            <input
              type="text"
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="e.g. Groceries"
              className="input"
            />
          </div>

          <div>
            <label className="label">Color</label>
            <div className="flex flex-wrap gap-2">
              {COLOR_PRESETS.map((color) => (
                <button
                  key={color}
                  onClick={() => setForm({ ...form, color })}
                  className="w-9 h-9 rounded-lg transition-all hover:scale-110"
                  style={{
                    backgroundColor: color,
                    outline: form.color === color ? '3px solid #0f172a' : 'none',
                    outlineOffset: '2px',
                  }}
                />
              ))}
            </div>
          </div>

          <div>
            <label className="label">Preview</label>
            <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
              <div
                className="w-11 h-11 rounded-xl flex items-center justify-center text-white"
                style={{ backgroundColor: form.color }}
              >
                <span className="text-lg font-bold">{(form.name || '?')[0].toUpperCase()}</span>
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-900">{form.name || 'Category name'}</p>
                <p className="text-xs text-slate-500 capitalize">{form.type}</p>
              </div>
            </div>
          </div>

          <button onClick={handleSave} disabled={saving} className="btn-primary w-full">
            {saving ? 'Saving…' : editing ? 'Save changes' : 'Add category'}
          </button>
        </div>
      </Modal>

      {/* Delete confirm */}
      <Modal open={!!confirmDelete} onClose={() => setConfirmDelete(null)} title="Delete Category">
        <div className="space-y-4">
          <p className="text-sm text-slate-600">
            Delete <span className="font-semibold text-slate-900">{confirmDelete?.name}</span>?
            Transactions in this category will remain but become uncategorized. Budgets for this
            category will be deleted.
          </p>
          <div className="flex gap-3">
            <button onClick={() => setConfirmDelete(null)} className="btn-secondary flex-1">
              Cancel
            </button>
            <button onClick={handleDelete} className="btn-danger flex-1">
              <Trash2 size={16} /> Delete
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
